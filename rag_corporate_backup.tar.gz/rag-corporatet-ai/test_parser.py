from app.config import settings
from app.core.parser import read_data_folder

print("🔬 Тест парсера запущен...")

# Используем наш генератор
doc_generator = read_data_folder(settings.DATA_PATH)

count = 0
for filename, text in doc_generator:
    count += 1
    preview = text[:100].replace('\n', ' ') # Берем первые 100 символов для показа
    print(f"\n📄 Файл #{count}: {filename}")
    print(f"📝 Начало текста: {preview}...")
    print("-" * 30)

if count == 0:
    print("⚠️ Файлы не найдены или папка пуста.")
else:
    print(f"\n✅ Успех! Прочитано документов: {count}")