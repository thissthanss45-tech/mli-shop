import os
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Обязательные ключи (Google убрали)
    GROQ_API_KEY: str
    TELEGRAM_BOT_TOKEN: str

    # Настройки путей
    DATA_PATH: str = "data"
    INDICES_PATH: str = "indices"
    
    # Параметры моделей
    MODEL_NAME: str = "llama-3.3-70b-versatile"
    # Теперь используем локальную модель (ключ не нужен)
    EMBEDDING_MODEL: str = "paraphrase-multilingual-MiniLM-L12-v2" 

    # Чтение .env
    model_config = SettingsConfigDict(env_file=".env", env_ignore_empty=True, extra="ignore")

settings = Settings()

if __name__ == "__main__":
    print(f"✅ Настройки загружены!")
    print(f"🤖 LLM Модель: {settings.MODEL_NAME}")
    print(f"🧠 Embeddings: {settings.EMBEDDING_MODEL} (Локально)")