import os
import asyncio
from app.core.builder import build_knowledge_base
from aiogram import Router, F , Bot
from aiogram.types import Message, File
from app.config import settings
from aiogram.filters import CommandStart, StateFilter
from aiogram.fsm.context import FSMContext

from app.bot.keyboards.reply import get_main_keyboard
from app.bot.states import ChatStates
# Подключаем наш мозг
from app.core.rag import RAGService

router = Router()

# 1. Инициализируем RAG один раз при запуске
# Это может занять пару секунд (загрузка модели)
print("⏳ Инициализация RAG в боте...")
rag_service = RAGService()
print("✅ RAG готов к работе в боте.")

# --- БАЗОВЫЕ КОМАНДЫ ---

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    # Сбрасываем любые состояния при старте
    await state.clear()
    
    await message.answer(
        text=(
            "👋 Привет, Командир!\n\n"
            "Система RAG готова к работе.\n"
            "Нажми 'AI Chat', чтобы задать вопрос по документам."
        ),
        reply_markup=get_main_keyboard()
    )

# --- ОБРАБОТКА КНОПОК ---

@router.message(F.text == "AI Chat 🧠✨")
async def btn_chat_reaction(message: Message, state: FSMContext):
    # Включаем режим ожидания вопроса
    await state.set_state(ChatStates.waiting_for_question)
    
    await message.answer(
        "🧠 **Режим AI активирован.**\n\n"
        "Напиши свой вопрос, и я поищу ответ в документах.\n"
        "Чтобы выйти, нажми любую другую кнопку меню.",
        parse_mode="Markdown"
    )

@router.message(F.text == "ЧаВо (FAQ) 📖")
async def btn_faq_reaction(message: Message, state: FSMContext):
    await state.clear() # Выходим из режима AI, если были там
    await message.answer("Раздел FAQ в разработке. 🛠")

@router.message(F.text == "Загрузить документ 📤")
async def btn_upload_reaction(message: Message, state: FSMContext):
    # Включаем режим ожидания файла
    await state.set_state(ChatStates.waiting_for_upload)
    
    await message.answer(
        "📂 **Режим загрузки активирован.**\n\n"
        "Отправь мне файл (PDF или DOCX), и я добавлю его в нашу базу данных.\n"
        "Жду документ...",
        parse_mode="Markdown"
    )

# --- ЛОГИКА ОТВЕТОВ (САМОЕ ГЛАВНОЕ) ---

# Этот хендлер ловит текст ТОЛЬКО если включен режим waiting_for_question
@router.message(StateFilter(ChatStates.waiting_for_question))
async def handle_rag_question(message: Message):
    user_text = message.text
    
    # Игнорируем, если пользователь случайно нажал кнопку меню (они обработаются выше)
    if user_text in ["AI Chat 🧠✨", "ЧаВо (FAQ) 📖", "Загрузить документ 📤"]:
        return

    # Отправляем уведомление, что "думаем" (полезно для UX)
    wait_msg = await message.answer("🕵️ Анализирую документы...")

    # Обращаемся к мозгу (это может занять 2-5 секунд)
    # Запускаем в отдельном потоке, чтобы не морозить бота, но пока для простоты так:
    response = rag_service.get_answer(user_text)

    # Удаляем сообщение "Анализирую..."
    await wait_msg.delete()

    # Отправляем ответ
    await message.answer(response)

    # Ловим документы, НО только если мы в режиме waiting_for_upload
@router.message(StateFilter(ChatStates.waiting_for_upload), F.document)
async def handle_document_upload(message: Message, bot: Bot, state: FSMContext):
    document = message.document
    file_name = document.file_name

    if not (file_name.lower().endswith('.pdf') or file_name.lower().endswith('.docx')):
        await message.answer("⚠️ Я понимаю только PDF и DOCX. Попробуй другой файл.")
        return

    wait_msg = await message.answer(f"📥 Скачиваю файл: {file_name}...")

    destination = os.path.join(settings.DATA_PATH, file_name)

    try:
        # 1. Скачиваем
        await bot.download(document, destination=destination)
        
        await wait_msg.edit_text(
            f"✅ Файл сохранен: `{file_name}`\n"
            "⚙️ **Начинаю чтение и индексацию...**\n"
            "Подождите, я обновляю нейронные связи...",
            parse_mode="Markdown"
        )

        # 2. Пересборка базы (на диске)
        total_chunks = await asyncio.to_thread(build_knowledge_base)
        
        # 3. ВАЖНО: Обновляем оперативную память бота!
        # Мы используем глобальную переменную rag_service, которая объявлена в начале файла
        rag_service.refresh_knowledge()
        
        # 4. Успех
        await message.answer(
            f"🎉 **База знаний обновлена!**\n\n"
            f"Теперь я знаю содержимое `{file_name}`.\n"
            f"Всего фрагментов в памяти: {total_chunks}.\n\n"
            "Смело задавай вопросы!",
            parse_mode="Markdown"
        )
        
        await state.clear()
        
    except Exception as e:
        await message.answer(f"❌ Произошла ошибка: {e}")
        await state.clear()

        
