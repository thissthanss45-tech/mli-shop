import asyncio
import logging
from aiogram import Bot, Dispatcher
from app.config import settings
from app.bot.handlers import base

# Настройка логирования (чтобы видеть в терминале, что происходит)
logging.basicConfig(level=logging.INFO)

async def main():
    # 1. Создаем объект бота
    bot = Bot(token=settings.TELEGRAM_BOT_TOKEN)
    
    # 2. Создаем диспетчер (мозг, обрабатывающий события)
    dp = Dispatcher()
    
    # 3. Подключаем наши обработчики (роутеры)
    dp.include_router(base.router)

    # 4. Удаляем старые сообщения (webhook), чтобы бот не отвечал на то, что было, пока он спал
    await bot.delete_webhook(drop_pending_updates=True)
    
    print("🚀 Бот запущен! Нажми /start в Telegram.")
    
    # 5. Запускаем бесконечный цикл прослушивания
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("🛑 Бот остановлен.")