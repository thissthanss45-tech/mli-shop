from groq import Groq
from app.config import settings
from app.retrieval.search import SearchEngine

class RAGService:
    def __init__(self):
        # 1. Сначала подключаем Groq
        self.client = Groq(api_key=settings.GROQ_API_KEY)
        
        # 2. ВАЖНО: Сначала создаем объект поиска!
        self.search_engine = SearchEngine()
        
        # (Убрали отсюда лишний вызов reload_index, так как SearchEngine 
        # и так загружается сам при создании через свой __init__)

    def refresh_knowledge(self):
        """Метод для принудительного обновления базы (вызывается после загрузки файла)"""
        self.search_engine.reload_index()

    def get_answer(self, user_question: str) -> str:
        print(f"\n🔎 ВОПРОС: {user_question}")
        
        # 1. Ищем контекст (берем 7 кусков для надежности)
        context_chunks = self.search_engine.search(user_question, top_k=7)
        
        # 2. Логируем для проверки
        if context_chunks:
            print(f"📚 НАЙДЕНО КУСКОВ: {len(context_chunks)}")
            # Берем первый кусок, обрезаем переносы строк для красоты лога
            preview = context_chunks[0][:100].replace('\n', ' ')
            print(f"📄 ПРИМЕР: {preview}...")
        else:
            print("⚠️ КОНТЕКСТ НЕ НАЙДЕН")

        if not context_chunks:
            context_text = "Информации в базе данных не найдено."
        else:
            context_text = "\n\n---\n\n".join(context_chunks)
        
        # 3. Умный промпт
        system_prompt = (
            "Ты — умный аналитик корпоративных данных. "
            "Твоя задача — помочь пользователю, используя предоставленный ниже контекст. "
            "\nПРАВИЛА:"
            "\n1. Если в контексте есть ответ — используй его."
            "\n2. Если прямой информации нет, попробуй сделать логический вывод, но начни со слов 'Судя по документам...'."
            "\n3. Если контекст совсем не подходит, ответь из общих знаний, но предупреди об этом."
            "\n4. Отвечай на русском языке."
        )
        
        user_prompt = f"""
        КОНТЕКСТ:
        {context_text}
        
        ВОПРОС:
        {user_question}
        """

        try:
            chat_completion = self.client.chat.completions.create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                model=settings.MODEL_NAME,
                temperature=0.4,
            )
            return chat_completion.choices[0].message.content
        except Exception as e:
            print(f"❌ ОШИБКА GROQ: {e}")
            return f"⚠️ Произошла ошибка: {e}"