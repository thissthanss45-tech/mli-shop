import os
import fitz  # Это PyMuPDF
import docx2txt
from typing import Generator, Tuple

def extract_text_from_pdf(file_path: str) -> str:
    """Читает PDF через мощный PyMuPDF (fitz)."""
    text = ""
    try:
        # Открываем документ
        with fitz.open(file_path) as doc:
            for page in doc:
                # get_text("text") достает чистый текст, игнорируя сложную верстку
                text += page.get_text("text") + "\n"
    except Exception as e:
        print(f"⚠️ Ошибка чтения PDF {file_path}: {e}")
    return text

def extract_text_from_docx(file_path: str) -> str:
    """Читает DOCX."""
    try:
        text = docx2txt.process(file_path)
        return text
    except Exception as e:
        print(f"⚠️ Ошибка чтения DOCX {file_path}: {e}")
        return ""

def read_data_folder(data_path: str) -> Generator[Tuple[str, str], None, None]:
    """ГЕНЕРАТОР: Проходит по папке."""
    if not os.path.exists(data_path):
        print(f"❌ Папка {data_path} не найдена!")
        return

    files_count = 0
    print(f"📂 Сканирую папку: {data_path}")

    for filename in os.listdir(data_path):
        file_path = os.path.join(data_path, filename)
        
        if not os.path.isfile(file_path):
            continue

        text = ""
        # Теперь у нас мощный движок для PDF
        if filename.lower().endswith(".pdf"):
            text = extract_text_from_pdf(file_path)
        elif filename.lower().endswith(".docx"):
            text = extract_text_from_docx(file_path)
        else:
            continue

        if text.strip():
            files_count += 1
            yield filename, text 
    
    print(f"✅ Обработка завершена. Прочитано файлов: {files_count}")