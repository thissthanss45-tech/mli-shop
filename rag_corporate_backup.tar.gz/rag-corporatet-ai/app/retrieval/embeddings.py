from sentence_transformers import SentenceTransformer
from app.config import settings
import numpy as np

class Embedder:
    def __init__(self):
        print(f"🧠 Загружаю модель эмбеддингов: {settings.EMBEDDING_MODEL}...")
        # device='cpu' явно указываем, так как у нас нет GPU
        self.model = SentenceTransformer(settings.EMBEDDING_MODEL, device='cpu')
        print("✅ Модель готова.")

    def get_embedding(self, text: str) -> np.ndarray:
        """Превращает строку в вектор."""
        # normalize_embeddings=True важно для косинусного сходства (поиска)
        embedding = self.model.encode(text, normalize_embeddings=True)
        return np.array(embedding, dtype='float32')

    def get_embeddings(self, texts: list[str]) -> np.ndarray:
        """Превращает список строк в матрицу векторов (для батчей)."""
        embeddings = self.model.encode(texts, normalize_embeddings=True, show_progress_bar=True)
        return np.array(embeddings, dtype='float32')