from app.retrieval.indexer import FAISSIndex
from app.retrieval.embeddings import Embedder
from typing import List

class SearchEngine:
    def __init__(self):
        self.indexer = FAISSIndex()
        self.embedder = Embedder()
        
        # Загружаем индекс сразу при старте
        loaded = self.indexer.load()
        if not loaded:
            print("⚠️ ВНИМАНИЕ: Индекс не найден! Поиск работать не будет.")

    def reload_index(self):
        """ПРИНУДИТЕЛЬНАЯ перезагрузка индекса с диска."""
        print("🔄 SearchEngine: Обновляю индекс в памяти...")
        self.indexer.load()
        print("✅ SearchEngine: Индекс обновлен.")

    def search(self, query: str, top_k: int = 3) -> List[str]:
        """
        Ищет top_k самых похожих кусков текста.
        """
        if not self.indexer.index:
            return []

        # 1. Превращаем вопрос пользователя в вектор
        query_vector = self.embedder.get_embedding(query)
        
        # FAISS ожидает матрицу (1, dimension), делаем reshape
        query_vector = query_vector.reshape(1, -1)
        
        # 2. Ищем в FAISS ближайших соседей
        # D - дистанции (насколько похоже), I - индексы (номера в базе)
        distances, indices = self.indexer.index.search(query_vector, top_k)
        
        results = []
        # 3. Достаем тексты по найденным номерам
        for idx in indices[0]:
            if idx != -1 and idx < len(self.indexer.metadata):
                item = self.indexer.metadata[idx]
                # Добавляем текст (можно добавить и имя файла, если нужно)
                results.append(item["text"])
                
        return results