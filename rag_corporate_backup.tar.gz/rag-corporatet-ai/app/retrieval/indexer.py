import os
import faiss
import numpy as np
import pickle
from app.config import settings

class FAISSIndex:
    def __init__(self, dimension: int = 384):
        self.dimension = dimension
        self.index_path = os.path.join(settings.INDICES_PATH, "faiss_store.index")
        self.meta_path = os.path.join(settings.INDICES_PATH, "metadata.pkl")
        
        self.metadata = [] 
        self.index = None

    def create_adaptive_index(self, vector_count: int):
        """
        Создает индекс в зависимости от количества данных.
        """
        if vector_count < 2000:
            print(f"⚠️ Мало данных ({vector_count} шт). Использую легкий индекс FlatL2 (без сжатия).")
            # FlatL2 — простой, точный, не требует обучения. Идеален для тестов.
            self.index = faiss.IndexFlatL2(self.dimension)
        else:
            print(f"📊 Много данных ({vector_count} шт). Использую сжатый индекс IVFPQ.")
            # IVFPQ — сжатый, требует обучения. Идеален для продакшена.
            quantizer_str = "IVF100,PQ32" 
            self.index = faiss.index_factory(self.dimension, quantizer_str)

    def train(self, vectors: np.ndarray):
        """
        Обучает индекс, если это необходимо.
        """
        # Если индекс еще не создан, создаем его, зная размер данных
        if self.index is None:
            self.create_adaptive_index(len(vectors))

        if not self.index.is_trained:
            print(f"🎓 Начинаю обучение индекса...")
            self.index.train(vectors)
            print("✅ Обучение завершено!")

    def add_vectors(self, vectors: np.ndarray, new_metadata: list):
        """Добавляет векторы."""
        # Если добавляем данные первый раз и индекс не создан (случай батчей без обучения)
        if self.index is None:
             self.create_adaptive_index(len(vectors))
        
        self.index.add(vectors)
        self.metadata.extend(new_metadata)
        print(f"📥 Добавлено {len(vectors)} векторов. Всего в базе: {self.index.ntotal}")

    def save(self):
        print("💾 Сохраняю индекс на диск...")
        if not os.path.exists(settings.INDICES_PATH):
            os.makedirs(settings.INDICES_PATH)
        
        if self.index:
            faiss.write_index(self.index, self.index_path)
        
        with open(self.meta_path, "wb") as f:
            pickle.dump(self.metadata, f)
        print("✅ Все данные успешно сохранены.")

    def load(self):
        if not os.path.exists(self.index_path):
            print("⚠️ Индекс не найден.")
            return False
            
        print("📂 Загружаю индекс с диска...")
        self.index = faiss.read_index(self.index_path)
        with open(self.meta_path, "rb") as f:
            self.metadata = pickle.load(f)
        print(f"✅ Индекс загружен. Векторов: {self.index.ntotal}")
        return True