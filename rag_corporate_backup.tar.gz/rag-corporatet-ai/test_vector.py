import time
from app.core.parser import read_data_folder
from app.core.splitter import TextSplitter
from app.retrieval.embeddings import Embedder
from app.config import settings

def run_test():
    # 1. Инициализация
    splitter = TextSplitter(chunk_size=500, chunk_overlap=50)
    embedder = Embedder()
    
    print("\n🚀 Начинаем тест векторизации...\n")

    # 2. Читаем файлы (возьмем первый попавшийся)
    doc_gen = read_data_folder(settings.DATA_PATH)
    
    try:
        filename, text = next(doc_gen) # Берем только первый файл
        print(f"📄 Обрабатываем файл: {filename}")
        
        # 3. Режем на куски
        chunks = splitter.split_text(text)
        print(f"🔪 Текст разбит на {len(chunks)} частей.")
        
        if not chunks:
            print("⚠️ Текст пустой, нечего векторизовать.")
            return

        # 4. Векторизуем (замеряем время)
        print("⏳ Генерирую векторы (это нагрузит CPU)...")
        start_time = time.time()
        
        # Берем первые 5 кусочков для теста, чтобы долго не ждать
        test_chunks = chunks[:5] 
        vectors = embedder.get_embeddings(test_chunks)
        
        end_time = time.time()
        
        print(f"\n✅ Готово! Сгенерировано {len(vectors)} векторов.")
        print(f"⏱ Время обработки: {end_time - start_time:.2f} сек.")
        print(f"📐 Размерность вектора: {vectors.shape[1]} (должно быть 384)")
        print(f"🔢 Пример данных (первые 5 чисел): {vectors[0][:5]}")

    except StopIteration:
        print("❌ В папке data/ нет читаемых файлов.")
    except Exception as e:
        print(f"❌ Ошибка: {e}")

if __name__ == "__main__":
    run_test()