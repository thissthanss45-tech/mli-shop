from app.core.rag import RAGService

def test_brain():
    print("🤖 Запускаем RAG сервис...")
    rag = RAGService()
    
    while True:
        print("\n" + "="*50)
        question = input("❓ Задай вопрос по своим документам (или 'exit'): ")
        
        if question.lower() in ['exit', 'quit', 'выход']:
            break
            
        answer = rag.get_answer(question)
        print("\n🤖 Ответ системы:\n")
        print(answer)

if __name__ == "__main__":
    test_brain()