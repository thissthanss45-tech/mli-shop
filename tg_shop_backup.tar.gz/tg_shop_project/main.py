from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart, Command
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from sqlalchemy import select

from config import settings
from database import init_db, async_session_maker
from models import User, UserRole

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def start_handler(message: Message) -> None:
    async with async_session_maker() as session:
        stmt = select(User).where(User.tg_id == message.from_user.id)
        res = await session.execute(stmt)
        user = res.scalar_one_or_none()

        if user is None:
            role = (
                UserRole.OWNER.value
                if message.from_user.id == settings.owner_id
                else UserRole.CLIENT.value
            )

            user = User(
                tg_id=message.from_user.id,
                username=message.from_user.username,
                role=role,
            )
            session.add(user)
            await session.commit()

    # Меню по ролям
    if user.role == UserRole.OWNER.value:
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="📦 Товары")],
                [KeyboardButton(text="🏪 Витрина"), KeyboardButton(text="📊 Склад")],
                [KeyboardButton(text="📋 Заказы"), KeyboardButton(text="📈 Статистика")],
                [KeyboardButton(text="🤖 AI-помощник"), KeyboardButton(text="❌ Отмена")],
            ],
            resize_keyboard=True,
        )
        text = f"👑 Привет, владелец {message.from_user.first_name}!\nВыбери действие:"
    elif user.role == UserRole.STAFF.value:
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="🏪 Витрина"), KeyboardButton(text="📊 Склад")],
                [KeyboardButton(text="📋 Заказы")],
                [KeyboardButton(text="❌ Отмена")],
            ],
            resize_keyboard=True,
        )
        text = f"👔 Привет, сотрудник {message.from_user.first_name}!\nВыбери действие:"
    else:
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="🛍 Каталог"), KeyboardButton(text="🛒 Корзина")],
                [KeyboardButton(text="📦 Мои заказы"), KeyboardButton(text="🤖 AI-консультант")],
            ],
            resize_keyboard=True,
        )
        text = f"Привет, {message.from_user.first_name}!\nВыбери действие:"

    await message.answer(text, reply_markup=kb)


async def set_staff_handler(message: Message) -> None:
    if message.from_user.id != settings.owner_id:
        await message.answer("Эта команда доступна только владельцу.")
        return

    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Используй: /staff <telegram_id>")
        return

    target_tg_id = int(parts[1])

    async with async_session_maker() as session:
        stmt = select(User).where(User.tg_id == target_tg_id)
        res = await session.execute(stmt)
        user = res.scalar_one_or_none()

        if user is None:
            await message.answer(f"Пользователь с ID {target_tg_id} не найден в базе. Попросите его отправить /start боту.")
            return

        user.role = UserRole.STAFF.value
        await session.commit()

    await message.answer(f"✅ Пользователь {target_tg_id} теперь STAFF.")


async def unset_staff_handler(message: Message) -> None:
    if message.from_user.id != settings.owner_id:
        await message.answer("Эта команда доступна только владельцу.")
        return

    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Используй: /unstaff <telegram_id>")
        return

    target_tg_id = int(parts[1])

    async with async_session_maker() as session:
        stmt = select(User).where(User.tg_id == target_tg_id)
        res = await session.execute(stmt)
        user = res.scalar_one_or_none()

        if user is None:
            await message.answer(f"Пользователь с ID {target_tg_id} не найден в базе.")
            return

        user.role = UserRole.CLIENT.value
        await session.commit()

    await message.answer(f"✅ Пользователь {target_tg_id} теперь CLIENT.")


async def on_startup() -> None:
    logger.info("Инициализация БД…")
    await init_db()
    logger.info("БД готова.")


def setup_routers(dp: Dispatcher) -> None:
    from handlers import client_router, owner_router

    dp.include_router(owner_router)
    dp.include_router(client_router)


async def main() -> None:
    bot = Bot(token=settings.bot_token)
    storage = MemoryStorage()
    dp = Dispatcher(storage=storage)

    dp.message.register(start_handler, CommandStart())
    dp.message.register(set_staff_handler, Command("staff"))
    dp.message.register(unset_staff_handler, Command("unstaff"))

    setup_routers(dp)

    await on_startup()
    logger.info("Запускаю бота…")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())



