from __future__ import annotations

from datetime import datetime
from enum import Enum

from sqlalchemy import BigInteger, String, DateTime, Integer
from sqlalchemy.orm import Mapped, mapped_column

from database.db_manager import Base


class UserRole(str, Enum):
    OWNER = "owner"
    STAFF = "staff"
    CLIENT = "client"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)

    role: Mapped[str] = mapped_column(String(16), default=UserRole.CLIENT.value)

    ai_quota: Mapped[int] = mapped_column(Integer, default=0)
    ai_quota_reset_date: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow,
    )
