from __future__ import annotations

import asyncio

from database.db_manager import get_session
from database.catalog_repo import CatalogRepo


async def main() -> None:
    async for session in get_session():
        repo = CatalogRepo(session)
        categories = await repo.list_categories()
        print("CATEGORIES COUNT:", len(categories))
        for c in categories:
            print(f"- {c.id}: {c.name}")


if __name__ == "__main__":
    asyncio.run(main())
