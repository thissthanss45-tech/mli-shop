from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

if ENV_PATH.exists():
    load_dotenv(ENV_PATH)


@dataclass
class Settings:
    bot_token: str
    owner_id: int

    db_url: str

    groq_api_key: str
    ollama_api_key: str

    ai_client_start_quota: int
    ai_client_bonus_quota: int
    max_photos_per_model: int

    timezone: str

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            bot_token=os.environ["BOT_TOKEN"],
            owner_id=int(os.environ["OWNER_ID"]),
            db_url=os.environ.get("DB_URL", "sqlite+aiosqlite:///tg_shop.db"),
            groq_api_key=os.environ.get("GROQ_API_KEY", ""),
            ollama_api_key=os.environ.get("OLLAMA_API_KEY", ""),
            ai_client_start_quota=int(os.environ.get("AI_CLIENT_START_QUOTA", 1)),
            ai_client_bonus_quota=int(os.environ.get("AI_CLIENT_BONUS_QUOTA", 5)),
            max_photos_per_model=int(os.environ.get("MAX_PHOTOS_PER_MODEL", 10)),
            timezone=os.environ.get("TIMEZONE", "Europe/Moscow"),
        )


settings = Settings.from_env()
