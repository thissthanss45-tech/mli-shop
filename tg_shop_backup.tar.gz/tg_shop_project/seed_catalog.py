from __future__ import annotations

import asyncio

from database import async_session_maker
from database.catalog_repo import CatalogRepo


async def seed() -> None:
    async with async_session_maker() as session:
        repo = CatalogRepo(session)

        cat = await repo.get_or_create_category("Одежда (мужская)")
        brand = await repo.get_or_create_brand("Zilli")

        await repo.create_product(
            title="Брюки Zilli классические",
            price=49999.99,
            category=cat,
            brand=brand,
        )
        await repo.create_product(
            title="Брюки Zilli casual",
            price=45999.99,
            category=cat,
            brand=brand,
        )

        await session.commit()


if __name__ == "__main__":
    asyncio.run(seed())
