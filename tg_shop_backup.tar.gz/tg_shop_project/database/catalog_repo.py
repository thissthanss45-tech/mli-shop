from __future__ import annotations

from typing import Sequence

from sqlalchemy import select, func, delete
from sqlalchemy.ext.asyncio import AsyncSession

from models import Category, Brand, Product, Photo, ProductStock


class CatalogRepo:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ===== CATEGORIES =====

    async def get_or_create_category(self, name: str) -> Category:
        stmt = select(Category).where(Category.name == name)
        res = await self.session.execute(stmt)
        category = res.scalar_one_or_none()

        if category is None:
            category = Category(name=name)
            self.session.add(category)
            await self.session.flush()

        return category

    async def list_categories(self) -> Sequence[Category]:
        stmt = select(Category).order_by(Category.name)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def update_category_name(self, category_id: int, new_name: str) -> bool:
        stmt = select(Category).where(Category.id == category_id)
        res = await self.session.execute(stmt)
        category = res.scalar_one_or_none()
        
        if category:
            category.name = new_name
            await self.session.flush()
            return True
        return False

    async def delete_category(self, category_id: int) -> bool:
        stmt = select(Category).where(Category.id == category_id)
        res = await self.session.execute(stmt)
        category = res.scalar_one_or_none()
        
        if category:
            await self.session.delete(category)
            await self.session.flush()
            return True
        return False

    # ===== BRANDS =====

    async def get_or_create_brand(self, name: str) -> Brand:
        stmt = select(Brand).where(Brand.name == name)
        res = await self.session.execute(stmt)
        brand = res.scalar_one_or_none()

        if brand is None:
            brand = Brand(name=name)
            self.session.add(brand)
            await self.session.flush()

        return brand

    async def list_brands(self) -> Sequence[Brand]:
        stmt = select(Brand).order_by(Brand.name)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def update_brand_name(self, brand_id: int, new_name: str) -> bool:
        stmt = select(Brand).where(Brand.id == brand_id)
        res = await self.session.execute(stmt)
        brand = res.scalar_one_or_none()
        
        if brand:
            brand.name = new_name
            await self.session.flush()
            return True
        return False

    async def delete_brand(self, brand_id: int) -> bool:
        stmt = select(Brand).where(Brand.id == brand_id)
        res = await self.session.execute(stmt)
        brand = res.scalar_one_or_none()
        
        if brand:
            await self.session.delete(brand)
            await self.session.flush()
            return True
        return False

    # ===== PRODUCTS =====

    async def create_product(
        self,
        title: str,
        purchase_price: float,
        sale_price: float,
        category: Category,
        brand: Brand,
        description: str | None = None,
    ) -> Product:
        product = Product(
            title=title,
            purchase_price=purchase_price,
            sale_price=sale_price,
            category=category,
            brand=brand,
            description=description,
        )
        self.session.add(product)
        await self.session.flush()
        return product

    async def get_product_by_id(self, product_id: int) -> Product | None:
        stmt = select(Product).where(Product.id == product_id)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_products_by_category_brand(
        self,
        category_id: int,
        brand_id: int,
    ) -> Sequence[Product]:
        stmt = (
            select(Product)
            .where(
                Product.category_id == category_id,
                Product.brand_id == brand_id,
            )
            .order_by(Product.title)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def update_product(
        self,
        product_id: int,
        title: str | None = None,
        purchase_price: float | None = None,
        sale_price: float | None = None,
        description: str | None = None,
        category_id: int | None = None,
        brand_id: int | None = None,
    ) -> bool:
        stmt = select(Product).where(Product.id == product_id)
        res = await self.session.execute(stmt)
        product = res.scalar_one_or_none()
        
        if not product:
            return False
        
        if title is not None:
            product.title = title
        if purchase_price is not None:
            product.purchase_price = purchase_price
        if sale_price is not None:
            product.sale_price = sale_price
        if description is not None:
            product.description = description
        if category_id is not None:
            product.category_id = category_id
        if brand_id is not None:
            product.brand_id = brand_id
        
        await self.session.flush()
        return True

    async def delete_product(self, product_id: int) -> bool:
        stmt = select(Product).where(Product.id == product_id)
        res = await self.session.execute(stmt)
        product = res.scalar_one_or_none()
        
        if product:
            await self.session.delete(product)
            await self.session.flush()
            return True
        return False

    # ===== PRODUCT STOCK (остатки) =====

    async def add_stock(self, product: Product, size: str, quantity: int) -> ProductStock:
        stock = ProductStock(
            product=product,
            size=size,
            quantity=quantity,
        )
        self.session.add(stock)
        await self.session.flush()
        return stock

    async def get_stock_by_product_and_size(
        self,
        product_id: int,
        size: str,
    ) -> ProductStock | None:
        stmt = select(ProductStock).where(
            ProductStock.product_id == product_id,
            ProductStock.size == size,
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_stock_by_product(self, product_id: int) -> Sequence[ProductStock]:
        stmt = (
            select(ProductStock)
            .where(ProductStock.product_id == product_id)
            .order_by(ProductStock.size)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def update_stock_quantity(
        self,
        product_id: int,
        size: str,
        quantity: int,
    ) -> bool:
        stock = await self.get_stock_by_product_and_size(product_id, size)
        
        if stock:
            stock.quantity = quantity
            await self.session.flush()
            return True
        return False

    async def delete_stock(self, product_id: int, size: str) -> bool:
        stmt = delete(ProductStock).where(
            ProductStock.product_id == product_id,
            ProductStock.size == size,
        )
        await self.session.execute(stmt)
        await self.session.flush()
        return True

    # ===== PHOTOS =====

    async def count_photos_for_product(self, product_id: int) -> int:
        stmt = select(func.count(Photo.id)).where(Photo.product_id == product_id)
        res = await self.session.execute(stmt)
        return int(res.scalar_one())

    async def add_photo(self, product: Product, file_id: str, max_photos: int = 10) -> Photo:
        count = await self.count_photos_for_product(product.id)
        if count >= max_photos:
            raise ValueError(f"Превышен лимит фото ({max_photos}) для модели")

        photo = Photo(product=product, file_id=file_id)
        self.session.add(photo)
        await self.session.flush()
        return photo

    async def list_photos_for_product(self, product_id: int) -> Sequence[Photo]:
        stmt = select(Photo).where(Photo.product_id == product_id).order_by(Photo.id)
        res = await self.session.execute(stmt)
        return res.scalars().all()



