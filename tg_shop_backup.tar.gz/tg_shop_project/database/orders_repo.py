from __future__ import annotations

from typing import Sequence
from datetime import datetime

from sqlalchemy import select, func, update
from sqlalchemy.ext.asyncio import AsyncSession

from models import CartItem, Product, User, Order, OrderItem, OrderStatus


class OrdersRepo:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ---------- КОРЗИНА ----------

    async def add_to_cart(
        self,
        user: User,
        product: Product,
        size: str,
        quantity: int = 1,
    ) -> CartItem:
        item = CartItem(
            user_id=user.id,
            product_id=product.id,
            size=size,
            quantity=quantity,
            price_at_add=product.sale_price,
        )
        self.session.add(item)
        await self.session.flush()
        return item

    async def list_cart_items(self, user: User) -> Sequence[CartItem]:
        stmt = (
            select(CartItem)
            .where(CartItem.user_id == user.id)
            .order_by(CartItem.created_at.desc())
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def delete_cart_item(self, user: User, item_id: int) -> bool:
        stmt = select(CartItem).where(
            CartItem.id == item_id,
            CartItem.user_id == user.id,
        )
        res = await self.session.execute(stmt)
        item = res.scalar_one_or_none()
        if item is None:
            return False
        await self.session.delete(item)
        await self.session.flush()
        return True

    async def clear_cart(self, user: User) -> None:
        stmt = select(CartItem).where(CartItem.user_id == user.id)
        res = await self.session.execute(stmt)
        items = res.scalars().all()
        for it in items:
            await self.session.delete(it)
        await self.session.flush()

    async def get_cart_total(self, user: User) -> float:
        stmt = select(
            func.coalesce(
                func.sum(CartItem.price_at_add * CartItem.quantity),
                0,
            )
        ).where(CartItem.user_id == user.id)
        res = await self.session.execute(stmt)
        return float(res.scalar_one())

    # ---------- ЗАКАЗЫ ----------

    async def create_order(
        self,
        user: User,
        full_name: str,
        phone: str,
        address: str,
        cart_items: Sequence[CartItem],
    ) -> Order:
        total_price = 0.0
        profit = 0.0

        order = Order(
            user_id=user.id,
            full_name=full_name,
            phone=phone,
            address=address,
            total_price=0,
            profit=0,
            status=OrderStatus.NEW.value,
        )
        self.session.add(order)
        await self.session.flush()

        for cart_item in cart_items:
            # Получаем актуальный товар
            stmt = select(Product).where(Product.id == cart_item.product_id)
            res = await self.session.execute(stmt)
            product = res.scalar_one()

            order_item = OrderItem(
                order_id=order.id,
                product_id=product.id,
                size=cart_item.size,
                quantity=cart_item.quantity,
                purchase_price=product.purchase_price,
                sale_price=product.sale_price,
            )
            self.session.add(order_item)

            total_price += product.sale_price * cart_item.quantity
            profit += (product.sale_price - product.purchase_price) * cart_item.quantity

        order.total_price = total_price
        order.profit = profit

        await self.session.flush()
        return order

    async def get_order_by_id(self, order_id: int) -> Order | None:
        stmt = select(Order).where(Order.id == order_id)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_orders_by_status(self, status: str) -> Sequence[Order]:
        stmt = (
            select(Order)
            .where(Order.status == status)
            .order_by(Order.created_at.desc())
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def list_orders_by_user(self, user: User) -> Sequence[Order]:
        stmt = (
            select(Order)
            .where(Order.user_id == user.id)
            .order_by(Order.created_at.desc())
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def update_order_status(self, order_id: int, new_status: str) -> bool:
        stmt = select(Order).where(Order.id == order_id)
        res = await self.session.execute(stmt)
        order = res.scalar_one_or_none()
        
        if order:
            order.status = new_status
            order.updated_at = datetime.utcnow()
            await self.session.flush()
            return True
        return False

    async def get_order_items(self, order_id: int) -> Sequence[OrderItem]:
        stmt = select(OrderItem).where(OrderItem.order_id == order_id)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def count_orders_by_status(self, status: str) -> int:
        stmt = select(func.count(Order.id)).where(Order.status == status)
        res = await self.session.execute(stmt)
        return int(res.scalar_one())

    async def get_total_sales(self) -> float:
        stmt = select(func.coalesce(func.sum(Order.total_price), 0)).where(
            Order.status == OrderStatus.COMPLETED.value
        )
        res = await self.session.execute(stmt)
        return float(res.scalar_one())

    async def get_total_profit(self) -> float:
        stmt = select(func.coalesce(func.sum(Order.profit), 0)).where(
            Order.status == OrderStatus.COMPLETED.value
        )
        res = await self.session.execute(stmt)
        return float(res.scalar_one())

