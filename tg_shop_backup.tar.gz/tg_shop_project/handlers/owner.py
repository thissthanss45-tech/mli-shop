from __future__ import annotations

from typing import List, Dict, Any

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from sqlalchemy import select 

from config import settings
from database.db_manager import get_session
from database.catalog_repo import CatalogRepo
from models.users import UserRole
from models.catalog import Category, Brand, Product

owner_router = Router(name="owner")


# ---------- FSM СОСТОЯНИЯ ----------


class AddProductStates(StatesGroup):
    choose_category = State()
    choose_brand = State()
    enter_name = State()
    enter_purchase_price = State()
    enter_sale_price = State()
    ask_photos = State()
    upload_photos = State()
    enter_sizes = State()
    enter_quantity_for_size = State()


class AddCategoryBrandStates(StatesGroup):
    enter_category_name = State()
    enter_brand_name = State()




class DeleteProductStates(StatesGroup):
    choose_category = State()
    choose_brand = State()
    choose_product = State()
    confirm = State()


class DeleteCategoryStates(StatesGroup):
    choose = State()
    confirm = State()


class DeleteBrandStates(StatesGroup):
    choose = State()
    confirm = State()




# ---------- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ----------


def cancel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    return kb.as_markup()


def yes_no_cancel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Да", callback_data="owner:photos:yes")
    kb.button(text="⏭ Пропустить", callback_data="owner:photos:skip")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(2, 1)
    return kb.as_markup()


def done_cancel_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Готово", callback_data="owner:photos:done")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1, 1)
    return kb.as_markup()


def build_categories_kb(categories: List[Category]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for c in categories:
        kb.button(text=c.name, callback_data=f"owner:cat:{c.id}")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(2)
    return kb.as_markup()


def build_brands_kb(brands: List[Brand]) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for b in brands:
        kb.button(text=b.name, callback_data=f"owner:brand:{b.id}")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(2)
    return kb.as_markup()


async def show_owner_main_menu(message: Message) -> None:
    """
    Главное меню владельца.
    Кнопки должны совпадать с тем, что уже настроено в main.py.
    """
    from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="📦 Товары"),
                KeyboardButton(text="🏪 Витрина"),
            ],
            [
                KeyboardButton(text="📊 Склад"),
                KeyboardButton(text="📋 Заказы"),
            ],
            [
                KeyboardButton(text="📈 Статистика"),
                KeyboardButton(text="🤖 AI"),
            ],
            [
                KeyboardButton(text="❌ Отмена"),
            ],
        ],
        resize_keyboard=True,
    )
    await message.answer("Главное меню владельца:", reply_markup=kb)


async def ensure_owner(message: Message) -> bool:
    """
    Проверка: пользователь — владелец?
    Сейчас ориентируемся на OWNER_ID из .env.
    Позже можно заменить на проверку по БД.
    """
    owner_id = settings.owner_id
    if message.from_user.id != owner_id:
        await message.answer("⛔ Доступно только владельцу магазина.")
        return False
    return True


# ---------- СТАРТ МЕНЮ ВЛАДЕЛЬЦА И ДОБАВЛЕНИЕ ТОВАРА ----------


@owner_router.message(Command("owner"))
async def owner_command_handler(message: Message) -> None:
    if not await ensure_owner(message):
        return
    await show_owner_main_menu(message)


@owner_router.message(F.text == "📦 Товары")
async def owner_menu_products(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    from aiogram.utils.keyboard import ReplyKeyboardBuilder

    kb = ReplyKeyboardBuilder()
    kb.button(text="➕ Добавить категорию")
    kb.button(text="➕ Добавить бренд")
    kb.button(text="➕ Добавить товар")
    kb.button(text="✏️ Редактировать товар")
    kb.button(text="❌ Удалить товар")
    kb.button(text="🗑 Удалить категорию")
    kb.button(text="🗑 Удалить бренд")
    kb.button(text="⬅ Назад")
    kb.adjust(2, 2, 2, 2)

    await message.answer(
        "📦 Управление товарами:\n\nВыбери действие:",
        reply_markup=kb.as_markup(resize_keyboard=True),
    )



@owner_router.message(F.text == "⬅ Назад")
async def owner_back_to_main(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return
    await state.clear()
    await show_owner_main_menu(message)


# ---------- ДОБАВЛЕНИЕ КАТЕГОРИИ ----------


@owner_router.message(F.text == "➕ Добавить категорию")
async def owner_add_category_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    await state.set_state(AddCategoryBrandStates.enter_category_name)
    await message.answer(
        "Введи название категории (например: Одежда, Обувь):",
        reply_markup=cancel_kb(),
    )


@owner_router.message(AddCategoryBrandStates.enter_category_name)
async def owner_add_category_name(message: Message, state: FSMContext) -> None:
    name = (message.text or "").strip()
    print("DEBUG ADD CATEGORY NAME:", repr(name))  # 👈 добавляем лог

    if not name:
        await message.answer(
            "Название категории не может быть пустым. Введи ещё раз:",
            reply_markup=cancel_kb(),
        )
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        print("DEBUG BEFORE get_or_create_category")
        await repo.get_or_create_category(name=name)
        await session.commit()  # 👈 фиксируем изменения
        print("DEBUG AFTER get_or_create_category")


    await state.clear()
    await message.answer(f"✅ Категория «{name}» добавлена.")
    await owner_menu_products(message, state)



# ---------- ДОБАВЛЕНИЕ БРЕНДА ----------


@owner_router.message(F.text == "➕ Добавить бренд")
async def owner_add_brand_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    await state.set_state(AddCategoryBrandStates.enter_brand_name)
    await message.answer(
        "Введи название бренда (например: Zilli, Brioni):",
        reply_markup=cancel_kb(),
    )


@owner_router.message(AddCategoryBrandStates.enter_brand_name)
async def owner_add_brand_name(message: Message, state: FSMContext) -> None:
    name = (message.text or "").strip()
    if not name:
        await message.answer(
            "Название бренда не может быть пустым. Введи ещё раз:",
            reply_markup=cancel_kb(),
        )
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        await repo.get_or_create_brand(name=name)
        await session.commit()  # 👈 фиксируем изменения


    await state.clear()
    await message.answer(f"✅ Бренд «{name}» добавлен.")
    await owner_menu_products(message, state)


# ---------- ДОБАВЛЕНИЕ ТОВАРА ----------


@owner_router.message(F.text == "➕ Добавить товар")
async def owner_add_product_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        categories = await repo.list_categories()
        print("DEBUG CATEGORIES COUNT:", len(categories))

    if not categories:
        await message.answer(
            "Категории пока не созданы. Сначала добавь категорию через панель владельца.",
        )
        return


    await state.clear()
    await state.set_state(AddProductStates.choose_category)
    kb = build_categories_kb(list(categories))
    await message.answer(
        "Выбери категорию товара:",
        reply_markup=kb,
    )


# ---------- ОТМЕНА (РАБОТАЕТ НА ЛЮБОМ ШАГЕ FSM) ----------


@owner_router.callback_query(F.data == "owner:cancel")
async def owner_cancel_any_step(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.answer("✅ Действие отменено.")
    await show_owner_main_menu(callback.message)
    await callback.answer()


@owner_router.message(F.text == "❌ Отмена")
async def owner_cancel_from_reply(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("✅ Действие отменено.")
    await show_owner_main_menu(message)


# ---------- ВЫБОР КАТЕГОРИИ ----------


@owner_router.callback_query(
    AddProductStates.choose_category,
    F.data.startswith("owner:cat:"),
)
async def owner_choose_category(callback: CallbackQuery, state: FSMContext) -> None:
    category_id_str = callback.data.split(":")[-1]
    try:
        category_id = int(category_id_str)
    except ValueError:
        await callback.answer("Ошибка категории.", show_alert=True)
        return

    await state.update_data(category_id=category_id)

    # Загружаем бренды
    async for session in get_session():
        repo = CatalogRepo(session)
        brands = await repo.list_brands()

    if not brands:
        await callback.message.edit_text(
            "Бренды пока не созданы. Сначала добавь бренд через панель владельца.",
            reply_markup=None,
        )
        await state.clear()
        await callback.answer()
        return

    kb = build_brands_kb(list(brands))
    await state.set_state(AddProductStates.choose_brand)
    await callback.message.edit_text(
        "Выбери бренд товара:",
        reply_markup=kb,
    )
    await callback.answer()


# ---------- ВЫБОР БРЕНДА ----------


@owner_router.callback_query(
    AddProductStates.choose_brand,
    F.data.startswith("owner:brand:"),
)
async def owner_choose_brand(callback: CallbackQuery, state: FSMContext) -> None:
    brand_id_str = callback.data.split(":")[-1]
    try:
        brand_id = int(brand_id_str)
    except ValueError:
        await callback.answer("Ошибка бренда.", show_alert=True)
        return

    await state.update_data(brand_id=brand_id)
    await state.set_state(AddProductStates.enter_name)

    await callback.message.edit_text(
        "Введи название модели (например: Брюки Zilli классические):",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


# ---------- НАЗВАНИЕ МОДЕЛИ ----------


@owner_router.message(AddProductStates.enter_name)
async def owner_enter_name(message: Message, state: FSMContext) -> None:
    name = message.text.strip()
    if not name:
        await message.answer(
            "Название не может быть пустым. Введи название модели:",
            reply_markup=cancel_kb(),
        )
        return

    await state.update_data(name=name)
    await state.set_state(AddProductStates.enter_purchase_price)
    await message.answer(
        "Введи закупочную цену (число):",
        reply_markup=cancel_kb(),
    )


# ---------- ЗАКУПОЧНАЯ ЦЕНА ----------


@owner_router.message(AddProductStates.enter_purchase_price)
async def owner_enter_purchase_price(message: Message, state: FSMContext) -> None:
    text = message.text.replace(" ", "").replace(",", ".")
    try:
        value = float(text)
        if value <= 0:
            raise ValueError
    except ValueError:
        await message.answer(
            "Некорректное число. Введи закупочную цену ещё раз:",
            reply_markup=cancel_kb(),
        )
        return

    await state.update_data(purchase_price=value)
    await state.set_state(AddProductStates.enter_sale_price)
    await message.answer(
        "Введи продажную цену (число):",
        reply_markup=cancel_kb(),
    )


# ---------- ПРОДАЖНАЯ ЦЕНА ----------


@owner_router.message(AddProductStates.enter_sale_price)
async def owner_enter_sale_price(message: Message, state: FSMContext) -> None:
    text = message.text.replace(" ", "").replace(",", ".")
    try:
        value = float(text)
        if value <= 0:
            raise ValueError
    except ValueError:
        await message.answer(
            "Некорректное число. Введи продажную цену ещё раз:",
            reply_markup=cancel_kb(),
        )
        return

    data = await state.get_data()
    purchase_price = data.get("purchase_price")
    if purchase_price and value < purchase_price:
        await message.answer(
            "⚠️ Продажная цена меньше закупочной. Введи корректную цену или всё равно продолжи.\n"
            "Введи продажную цену ещё раз:",
            reply_markup=cancel_kb(),
        )
        return

    await state.update_data(sale_price=value)
    await state.set_state(AddProductStates.ask_photos)
    await message.answer(
        "Добавить фото товара? Можно до 10 фото.\n\nВыбери вариант:",
        reply_markup=yes_no_cancel_kb(),
    )


# ---------- ВОПРОС О ФОТО ----------


@owner_router.callback_query(AddProductStates.ask_photos, F.data == "owner:photos:yes")
async def owner_photos_yes(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(photos=[])
    await state.set_state(AddProductStates.upload_photos)
    await callback.message.edit_text(
        "Отправляй фото по одному сообщению (до 10 штук).\n\nКогда хватит — нажми «✅ Готово».",
        reply_markup=done_cancel_kb(),
    )
    await callback.answer()


@owner_router.callback_query(AddProductStates.ask_photos, F.data == "owner:photos:skip")
async def owner_photos_skip(callback: CallbackQuery, state: FSMContext) -> None:
    await state.update_data(photos=[])
    await state.set_state(AddProductStates.enter_sizes)
    await callback.message.edit_text(
        "Введи размеры через запятую, например:\n48, 50, 52",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


# ---------- ЗАГРУЗКА ФОТО (ДО 10) ----------


@owner_router.message(AddProductStates.upload_photos, F.photo)
async def owner_upload_photo(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    photos: List[str] = data.get("photos", [])

    if len(photos) >= 10:
        await message.answer(
            "Ты уже загрузил 10 фото. Нажми «✅ Готово» или «❌ Отмена».",
            reply_markup=done_cancel_kb(),
        )
        return

    file_id = message.photo[-1].file_id
    photos.append(file_id)
    await state.update_data(photos=photos)

    await message.answer(
        f"Фото сохранено ({len(photos)}/10).\n"
        "Отправь ещё фото или нажми «✅ Готово».",
        reply_markup=done_cancel_kb(),
    )


@owner_router.callback_query(AddProductStates.upload_photos, F.data == "owner:photos:done")
async def owner_photos_done(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddProductStates.enter_sizes)
    await callback.message.edit_text(
        "Введи размеры через запятую, например:\n48, 50, 52",
        reply_markup=cancel_kb(),
    )
    await callback.answer()


# ---------- РАЗМЕРЫ ----------


@owner_router.message(AddProductStates.enter_sizes)
async def owner_enter_sizes(message: Message, state: FSMContext) -> None:
    raw = message.text.replace(" ", "")
    parts = [p for p in raw.split(",") if p]

    if not parts:
        await message.answer(
            "Не получилось распознать размеры. Введи ещё раз, например:\n48, 50, 52",
            reply_markup=cancel_kb(),
        )
        return

    sizes = parts
    await state.update_data(sizes=sizes, quantities={}, current_size_index=0)

    current_size = sizes[0]
    await state.set_state(AddProductStates.enter_quantity_for_size)
    await message.answer(
        f"Введи количество для размера {current_size}:",
        reply_markup=cancel_kb(),
    )


# ---------- КОЛИЧЕСТВО ПО КАЖДОМУ РАЗМЕРУ ----------


@owner_router.message(AddProductStates.enter_quantity_for_size)
async def owner_enter_quantity_for_size(message: Message, state: FSMContext) -> None:
    text = message.text.replace(" ", "")
    try:
        qty = int(text)
        if qty < 0:
            raise ValueError
    except ValueError:
        data = await state.get_data()
        sizes: List[str] = data.get("sizes", [])
        idx = data.get("current_size_index", 0)
        current_size = sizes[idx] if idx < len(sizes) else "?"
        await message.answer(
            f"Некорректное количество. Введи число для размера {current_size}:",
            reply_markup=cancel_kb(),
        )
        return

    data = await state.get_data()
    sizes: List[str] = data.get("sizes", [])
    quantities: Dict[str, int] = data.get("quantities", {})
    idx = data.get("current_size_index", 0)

    if idx >= len(sizes):
        await message.answer(
            "Произошла ошибка с индексом размера. Попробуй начать заново.",
        )
        await state.clear()
        await show_owner_main_menu(message)
        return

    current_size = sizes[idx]
    quantities[current_size] = qty
    idx += 1

    # Если ещё есть размеры — спрашиваем следующий
    if idx < len(sizes):
        await state.update_data(quantities=quantities, current_size_index=idx)
        next_size = sizes[idx]
        await message.answer(
            f"Введи количество для размера {next_size}:",
            reply_markup=cancel_kb(),
        )
        return

    # Если размеров больше нет — создаём товар в БД
    await state.update_data(quantities=quantities)
    await create_product_in_db(message, state)


# ---------- СОХРАНЕНИЕ ТОВАРА В БД ----------


async def create_product_in_db(message: Message, state: FSMContext) -> None:
    data: Dict[str, Any] = await state.get_data()

    category_id = data.get("category_id")
    brand_id = data.get("brand_id")
    name = data.get("name")
    purchase_price = data.get("purchase_price")
    sale_price = data.get("sale_price")
    photos: List[str] = data.get("photos", [])
    sizes: List[str] = data.get("sizes", [])
    quantities: Dict[str, int] = data.get("quantities", {})

    async for session in get_session():
        repo = CatalogRepo(session)

        # загружаем объекты Category и Brand по id
        stmt_cat = select(Category).where(Category.id == category_id)
        res_cat = await session.execute(stmt_cat)
        category_obj = res_cat.scalar_one()

        stmt_brand = select(Brand).where(Brand.id == brand_id)
        res_brand = await session.execute(stmt_brand)
        brand_obj = res_brand.scalar_one()

        # создаём продукт
        product = await repo.create_product(
            title=name,
            purchase_price=purchase_price,
            sale_price=sale_price,
            category=category_obj,
            brand=brand_obj,
            description=None,
        )

        # фото (если есть)
        for file_id in photos:
            await repo.add_photo(product=product, file_id=file_id)

        # остатки по размерам
        for size in sizes:
            qty = quantities.get(size, 0)
            if qty > 0:
                await repo.add_stock(product=product, size=size, quantity=qty)

        await session.commit()

    await state.clear()
    await message.answer(
        "✅ Товар успешно создан и сохранён в базе.\n"
        "Категория, бренд, цены, фото и остатки по размерам записаны.",
    )
    await show_owner_main_menu(message)



# ---------- УДАЛЕНИЕ ТОВАРА ----------

@owner_router.message(F.text == "❌ Удалить товар")
async def owner_delete_product_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        categories = await repo.list_categories()

    if not categories:
        await message.answer("Категории пока не созданы. Нечего удалять.")
        return

    await state.clear()
    await state.set_state(DeleteProductStates.choose_category)
    kb = build_categories_kb(list(categories))
    await message.answer(
        "🗑 Удаление товара\n\nВыбери категорию:",
        reply_markup=kb,
    )


@owner_router.callback_query(
    DeleteProductStates.choose_category,
    F.data.startswith("owner:cat:"),
)
async def owner_delete_choose_category(callback: CallbackQuery, state: FSMContext) -> None:
    category_id = int(callback.data.split(":")[-1])
    await state.update_data(category_id=category_id)

    async for session in get_session():
        repo = CatalogRepo(session)
        brands = await repo.list_brands()

    if not brands:
        await callback.message.edit_text("Бренды не найдены.", reply_markup=None)
        await state.clear()
        await callback.answer()
        return

    kb = build_brands_kb(list(brands))
    await state.set_state(DeleteProductStates.choose_brand)
    await callback.message.edit_text("Выбери бренд:", reply_markup=kb)
    await callback.answer()


@owner_router.callback_query(
    DeleteProductStates.choose_brand,
    F.data.startswith("owner:brand:"),
)
async def owner_delete_choose_brand(callback: CallbackQuery, state: FSMContext) -> None:
    brand_id = int(callback.data.split(":")[-1])
    data = await state.get_data()
    category_id = data.get("category_id")

    async for session in get_session():
        repo = CatalogRepo(session)
        products = await repo.list_products_by_category_brand(category_id=category_id, brand_id=brand_id)


    if not products:
        await callback.message.edit_text(
            "Товары не найдены в этой категории и бренде.",
            reply_markup=None,
        )
        await state.clear()
        await callback.answer()
        return

    kb = InlineKeyboardBuilder()
    for prod in products:
        kb.button(
            text=f"{prod.title} — {prod.sale_price} ₽",
            callback_data=f"owner:delprod:{prod.id}",
        )
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.set_state(DeleteProductStates.choose_product)
    await callback.message.edit_text(
        "Выбери товар для удаления:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@owner_router.callback_query(
    DeleteProductStates.choose_product,
    F.data.startswith("owner:delprod:"),
)
async def owner_delete_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    product_id = int(callback.data.split(":")[-1])
    await state.update_data(product_id=product_id)

    async for session in get_session():
        product = await session.get(Product, product_id)

    if not product:
        await callback.message.edit_text("Товар не найден.", reply_markup=None)
        await state.clear()
        await callback.answer()
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Подтвердить удаление", callback_data="owner:confirm_delete")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.set_state(DeleteProductStates.confirm)
    await callback.message.edit_text(
        f"⚠️ Удалить товар?\n\n"
        f"Название: {product.title}\n"
        f"Цена: {product.sale_price} ₽\n\n"
        f"Это действие нельзя отменить.",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@owner_router.callback_query(
    DeleteProductStates.confirm,
    F.data == "owner:confirm_delete",
)
async def owner_delete_execute(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    product_id = data.get("product_id")

    async for session in get_session():
        repo = CatalogRepo(session)
        await repo.delete_product(product_id)
        await session.commit()

    await state.clear()
    await callback.message.edit_text("✅ Товар успешно удалён.", reply_markup=None)
    await show_owner_main_menu(callback.message)
    await callback.answer()



# ---------- УДАЛЕНИЕ КАТЕГОРИИ ----------

@owner_router.message(F.text == "🗑 Удалить категорию")
async def owner_delete_category_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        categories = await repo.list_categories()

    if not categories:
        await message.answer("Категории пока не созданы.")
        return

    kb = InlineKeyboardBuilder()
    for cat in categories:
        kb.button(text=cat.name, callback_data=f"owner:delcat:{cat.id}")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.clear()
    await state.set_state(DeleteCategoryStates.choose)
    await message.answer(
        "🗑 Удаление категории\n\nВыбери категорию:",
        reply_markup=kb.as_markup(),
    )


@owner_router.callback_query(
    DeleteCategoryStates.choose,
    F.data.startswith("owner:delcat:"),
)
async def owner_delete_category_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    category_id = int(callback.data.split(":")[-1])
    await state.update_data(category_id=category_id)

    async for session in get_session():
        category = await session.get(Category, category_id)

    if not category:
        await callback.message.edit_text("Категория не найдена.", reply_markup=None)
        await state.clear()
        await callback.answer()
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Подтвердить удаление", callback_data="owner:confirm_delcat")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.set_state(DeleteCategoryStates.confirm)
    await callback.message.edit_text(
        f"⚠️ Удалить категорию?\n\n"
        f"Название: {category.name}\n\n"
        f"⚠️ Все товары этой категории также будут удалены!",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@owner_router.callback_query(
    DeleteCategoryStates.confirm,
    F.data == "owner:confirm_delcat",
)
async def owner_delete_category_execute(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    category_id = data.get("category_id")

    async for session in get_session():
        repo = CatalogRepo(session)
        await repo.delete_category(category_id)
        await session.commit()

    await state.clear()
    await callback.message.edit_text("✅ Категория успешно удалена.", reply_markup=None)
    await show_owner_main_menu(callback.message)
    await callback.answer()


# ---------- УДАЛЕНИЕ БРЕНДА ----------

@owner_router.message(F.text == "🗑 Удалить бренд")
async def owner_delete_brand_start(message: Message, state: FSMContext) -> None:
    if not await ensure_owner(message):
        return

    async for session in get_session():
        repo = CatalogRepo(session)
        brands = await repo.list_brands()

    if not brands:
        await message.answer("Бренды пока не созданы.")
        return

    kb = InlineKeyboardBuilder()
    for brand in brands:
        kb.button(text=brand.name, callback_data=f"owner:delbrand:{brand.id}")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.clear()
    await state.set_state(DeleteBrandStates.choose)
    await message.answer(
        "🗑 Удаление бренда\n\nВыбери бренд:",
        reply_markup=kb.as_markup(),
    )


@owner_router.callback_query(
    DeleteBrandStates.choose,
    F.data.startswith("owner:delbrand:"),
)
async def owner_delete_brand_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    brand_id = int(callback.data.split(":")[-1])
    await state.update_data(brand_id=brand_id)

    async for session in get_session():
        brand = await session.get(Brand, brand_id)

    if not brand:
        await callback.message.edit_text("Бренд не найден.", reply_markup=None)
        await state.clear()
        await callback.answer()
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Подтвердить удаление", callback_data="owner:confirm_delbrand")
    kb.button(text="❌ Отмена", callback_data="owner:cancel")
    kb.adjust(1)

    await state.set_state(DeleteBrandStates.confirm)
    await callback.message.edit_text(
        f"⚠️ Удалить бренд?\n\n"
        f"Название: {brand.name}\n\n"
        f"⚠️ Все товары этого бренда также будут удалены!",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@owner_router.callback_query(
    DeleteBrandStates.confirm,
    F.data == "owner:confirm_delbrand",
)
async def owner_delete_brand_execute(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    brand_id = data.get("brand_id")

    async for session in get_session():
        repo = CatalogRepo(session)
        await repo.delete_brand(brand_id)
        await session.commit()

    await state.clear()
    await callback.message.edit_text("✅ Бренд успешно удалён.", reply_markup=None)
    await show_owner_main_menu(callback.message)
    await callback.answer()

