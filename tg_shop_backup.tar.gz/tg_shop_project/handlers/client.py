from __future__ import annotations

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from sqlalchemy import select

from database import async_session_maker
from database.catalog_repo import CatalogRepo
from database.orders_repo import OrdersRepo
from models import Category, Brand, Product, User, CartItem

client_router = Router()

# Простое состояние: ждём размер для конкретного товара
# key: user_tg_id, value: product_id

pending_size_for_product: dict[int, int] = {}
pending_qty_for_product: dict[int, int] = {}
pending_size_value: dict[int, str] = {}



# ---------- Клавиатуры каталога ----------


def build_categories_kb(categories: list[Category]) -> InlineKeyboardBuilder:
    kb = InlineKeyboardBuilder()
    for c in categories:
        kb.button(
            text=c.name,
            callback_data=f"cat:{c.id}",
        )
    kb.adjust(1)
    return kb


def build_brands_kb(category_id: int, brands: list[Brand]) -> InlineKeyboardBuilder:
    kb = InlineKeyboardBuilder()
    for b in brands:
        kb.button(
            text=b.name,
            callback_data=f"brand:{category_id}:{b.id}",
        )
    kb.button(text="⬅ Назад", callback_data="back:categories")
    kb.adjust(1)
    return kb


def build_products_kb(
    category_id: int,
    brand_id: int,
    products: list[Product],
) -> InlineKeyboardBuilder:
    kb = InlineKeyboardBuilder()
    for p in products:
        kb.button(
            text=p.title,
            callback_data=f"prod:{category_id}:{brand_id}:{p.id}",
        )
    kb.button(
        text="⬅ Назад",
        callback_data=f"back:brands:{category_id}",
    )
    kb.adjust(1)
    return kb


# ---------- Клавиатуры корзины ----------


def build_cart_kb(items: list[CartItem]) -> InlineKeyboardBuilder:
    kb = InlineKeyboardBuilder()
    for it in items:
        kb.button(
            text=f"❌ Удалить #{it.id}",
            callback_data=f"cart:del:{it.id}",
        )
    kb.button(text="⬅ В каталог", callback_data="back:categories")
    kb.adjust(1)
    return kb


# ---------- Команды каталога ----------


@client_router.message(Command("catalog"))
async def cmd_catalog(message: Message) -> None:
    async with async_session_maker() as session:
        repo = CatalogRepo(session)
        categories = await repo.list_categories()

    if not categories:
        await message.answer("Категории пока не созданы.")
        return

    kb = build_categories_kb(list(categories))
    await message.answer(
        "Выбери категорию:",
        reply_markup=kb.as_markup(),
    )


@client_router.message(Command("cart"))
async def cmd_cart(message: Message) -> None:
    async with async_session_maker() as session:
        # найдём User по tg_id
        res = await session.execute(
            select(User).where(User.tg_id == message.from_user.id),
        )
        user = res.scalar_one_or_none()
        if user is None:
            await message.answer("Пользователь не найден, отправь /start.")
            return

        orders_repo = OrdersRepo(session)
        items = await orders_repo.list_cart_items(user)
        total = await orders_repo.get_cart_total(user)

    if not items:
        await message.answer("Корзина пуста.")
        return

    lines = ["Твоя корзина:"]
    for it in items:
        lines.append(
            f"#{it.id}: {it.size} — {it.price_at_add} ₽ x {it.quantity}",
        )
    lines.append(f"\nИтого: {total} ₽")

    kb = build_cart_kb(list(items))
    await message.answer(
        "\n".join(lines),
        reply_markup=kb.as_markup(),
    )


# ---------- Каталог: кнопки ----------


@client_router.callback_query(F.data.startswith("cat:"))
async def cq_category(callback: CallbackQuery) -> None:
    _, cat_id_str = callback.data.split(":", maxsplit=1)
    category_id = int(cat_id_str)

    async with async_session_maker() as session:
        res = await session.execute(select(Category).where(Category.id == category_id))
        category = res.scalar_one_or_none()
        if category is None:
            await callback.answer("Категория не найдена.", show_alert=True)
            return

        repo = CatalogRepo(session)
        brands = await repo.list_brands()

    if not brands:
        await callback.message.edit_text("Бренды пока не созданы.")
        await callback.answer()
        return

    kb = build_brands_kb(category_id, list(brands))
    await callback.message.edit_text(
        f"Категория: {category.name}\nВыбери бренд:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("brand:"))
async def cq_brand(callback: CallbackQuery) -> None:
    _, cat_id_str, brand_id_str = callback.data.split(":", maxsplit=2)
    category_id = int(cat_id_str)
    brand_id = int(brand_id_str)

    async with async_session_maker() as session:
        res = await session.execute(select(Brand).where(Brand.id == brand_id))
        brand = res.scalar_one_or_none()
        if brand is None:
            await callback.answer("Бренд не найден.", show_alert=True)
            return

        repo = CatalogRepo(session)
        products = await repo.list_products_by_category_brand(
            category_id=category_id,
            brand_id=brand_id,
        )

    if not products:
        await callback.message.edit_text(
            f"Для бренда {brand.name} пока нет товаров.",
        )
        await callback.answer()
        return

    kb = build_products_kb(category_id, brand_id, list(products))
    await callback.message.edit_text(
        f"Бренд: {brand.name}\nВыбери модель:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("prod:"))
async def cq_product(callback: CallbackQuery) -> None:
    _, cat_id_str, brand_id_str, prod_id_str = callback.data.split(":", maxsplit=3)
    category_id = int(cat_id_str)
    brand_id = int(brand_id_str)
    product_id = int(prod_id_str)

    async with async_session_maker() as session:
        from sqlalchemy.orm import selectinload
        
        res = await session.execute(
            select(Product)
            .options(selectinload(Product.photos))
            .where(Product.id == product_id)
        )
        product = res.scalar_one_or_none()

    if product is None:
        await callback.answer("Товар не найден.", show_alert=True)
        return

    kb = InlineKeyboardBuilder()
    kb.button(
        text="🛒 В корзину",
        callback_data=f"cart:add:{product_id}",
    )
    
    # Если фото больше 1 — добавляем кнопку "Все фото"
    if len(product.photos) > 1:
        kb.button(
            text=f"📸 Все фото ({len(product.photos)})",
            callback_data=f"photos:{product_id}",
        )
    
    kb.button(
        text="⬅ Назад",
        callback_data=f"back:products:{category_id}:{brand_id}",
    )
    kb.adjust(1)

    text = f"Товар: {product.title}\nЦена: {product.sale_price} ₽"

    # Показываем первое фото
    if product.photos:
        photo_file_id = product.photos[0].file_id
        await callback.message.answer_photo(
            photo=photo_file_id,
            caption=text,
            reply_markup=kb.as_markup(),
        )
        await callback.message.delete()
    else:
        # Если фото нет - просто текст
        await callback.message.edit_text(
            text,
            reply_markup=kb.as_markup(),
        )
    
    await callback.answer()



@client_router.callback_query(F.data.startswith("photos:"))
async def cq_show_all_photos(callback: CallbackQuery) -> None:
    _, prod_id_str = callback.data.split(":", maxsplit=1)
    product_id = int(prod_id_str)

    async with async_session_maker() as session:
        from sqlalchemy.orm import selectinload
        from aiogram.types import InputMediaPhoto
        
        res = await session.execute(
            select(Product)
            .options(selectinload(Product.photos))
            .where(Product.id == product_id)
        )
        product = res.scalar_one_or_none()

    if product is None or not product.photos:
        await callback.answer("Фото не найдены.", show_alert=True)
        return

    # Создаём media group из всех фото
    media = [
        InputMediaPhoto(media=photo.file_id)
        for photo in product.photos
    ]

    await callback.message.answer_media_group(media=media)
    await callback.answer("Все фото товара")


# ---------- «Назад» ----------


@client_router.callback_query(F.data == "back:categories")
async def cq_back_categories(callback: CallbackQuery) -> None:
    async with async_session_maker() as session:
        repo = CatalogRepo(session)
        categories = await repo.list_categories()

    if not categories:
        await callback.message.edit_text("Категории пока не созданы.")
        await callback.answer()
        return

    kb = build_categories_kb(list(categories))
    await callback.message.edit_text(
        "Выбери категорию:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("back:brands:"))
async def cq_back_brands(callback: CallbackQuery) -> None:
    _, _, cat_id_str = callback.data.split(":", maxsplit=2)
    category_id = int(cat_id_str)

    async with async_session_maker() as session:
        res = await session.execute(select(Category).where(Category.id == category_id))
        category = res.scalar_one_or_none()
        if category is None:
            await callback.answer("Категория не найдена.", show_alert=True)
            return

        repo = CatalogRepo(session)
        brands = await repo.list_brands()

    if not brands:
        await callback.message.edit_text("Бренды пока не созданы.")
        await callback.answer()
        return

    kb = build_brands_kb(category_id, list(brands))
    await callback.message.edit_text(
        f"Категория: {category.name}\nВыбери бренд:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("back:products:"))
async def cq_back_products(callback: CallbackQuery) -> None:
    _, _, cat_id_str, brand_id_str = callback.data.split(":", maxsplit=3)
    category_id = int(cat_id_str)
    brand_id = int(brand_id_str)

    async with async_session_maker() as session:
        res = await session.execute(select(Brand).where(Brand.id == brand_id))
        brand = res.scalar_one_or_none()
        if brand is None:
            await callback.answer("Бренд не найден.", show_alert=True)
            return

        repo = CatalogRepo(session)
        products = await repo.list_products_by_category_brand(
            category_id=category_id,
            brand_id=brand_id,
        )

    if not products:
        await callback.message.edit_text(
            f"Для бренда {brand.name} пока нет товаров.",
        )
        await callback.answer()
        return

    kb = build_products_kb(category_id, brand_id, list(products))
    await callback.message.edit_text(
        f"Бренд: {brand.name}\nВыбери модель:",
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("cart:add:"))
async def cq_cart_add(callback: CallbackQuery) -> None:
    _, _, prod_id_str = callback.data.split(":", maxsplit=2)
    product_id = int(prod_id_str)

    user_tg_id = callback.from_user.id
    pending_size_for_product[user_tg_id] = product_id

    await callback.message.answer(
        "Введите, пожалуйста, размер (например: 48, 50, L, XL):",
    )
    await callback.answer()


# ---------- Корзина: добавить (после размера) и удалить ----------


@client_router.callback_query(F.data == "show:cart")
async def cq_show_cart(callback: CallbackQuery) -> None:
    async with async_session_maker() as session:
        res = await session.execute(
            select(User).where(User.tg_id == callback.from_user.id),
        )
        user = res.scalar_one_or_none()
        if user is None:
            await callback.answer("Пользователь не найден.", show_alert=True)
            return

        orders_repo = OrdersRepo(session)
        items = await orders_repo.list_cart_items(user)
        total = await orders_repo.get_cart_total(user)

    if not items:
        await callback.message.edit_text("Корзина пуста.")
        await callback.answer()
        return

    lines = ["Твоя корзина:"]
    for it in items:
        lines.append(
            f"#{it.id}: {it.size} — {it.price_at_add} ₽ x {it.quantity}",
        )
    lines.append(f"\nИтого: {total} ₽")

    kb = build_cart_kb(list(items))
    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.callback_query(F.data.startswith("cart:del:"))
async def cq_cart_delete(callback: CallbackQuery) -> None:
    _, _, item_id_str = callback.data.split(":", maxsplit=2)
    item_id = int(item_id_str)

    async with async_session_maker() as session:
        res = await session.execute(
            select(User).where(User.tg_id == callback.from_user.id),
        )
        user = res.scalar_one_or_none()
        if user is None:
            await callback.answer("Пользователь не найден.", show_alert=True)
            return

        orders_repo = OrdersRepo(session)
        ok = await orders_repo.delete_cart_item(user, item_id)
        items = await orders_repo.list_cart_items(user)
        total = await orders_repo.get_cart_total(user)
        await session.commit()

    if not ok:
        await callback.answer("Этой позиции уже нет в корзине.", show_alert=True)
        return

    if not items:
        await callback.message.edit_text("Корзина пуста.")
        await callback.answer()
        return

    lines = ["Твоя корзина:"]
    for it in items:
        lines.append(
            f"#{it.id}: {it.size} — {it.price_at_add} ₽ x {it.quantity}",
        )
    lines.append(f"\nИтого: {total} ₽")

    kb = build_cart_kb(list(items))
    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=kb.as_markup(),
    )
    await callback.answer()


@client_router.message(F.text.in_(["🛍 Каталог", "📦 Каталог"]))
async def menu_catalog(message: Message) -> None:
    await cmd_catalog(message)


@client_router.message(F.text == "🛒 Корзина")
async def menu_cart(message: Message) -> None:
    await cmd_cart(message)


@client_router.message(F.text == "📦 Мои заказы")
async def menu_my_orders(message: Message) -> None:
    await message.answer("Раздел «Мои заказы» пока в разработке.")


@client_router.message(F.text == "🤖 AI-консультант")
async def menu_ai(message: Message) -> None:
    await message.answer("AI-консультант пока в разработке. Скоро будет доступен!")


@client_router.message(F.text == "➕ Добавить товар")
async def menu_add_product(message: Message) -> None:
    await message.answer("Панель добавления товаров пока в разработке.")


@client_router.message(F.text == "📊 Заказы")
async def menu_orders(message: Message) -> None:
    await message.answer("Раздел управления заказами пока в разработке.")


@client_router.message(F.text == "📈 Статистика")
async def menu_stats(message: Message) -> None:
    await message.answer("Раздел статистики пока в разработке.")


@client_router.message(F.text)
async def catch_size_for_cart(message: Message) -> None:
    user_tg_id = message.from_user.id
    if user_tg_id not in pending_size_for_product:
        return

    size_text = message.text.strip()
    product_id = pending_size_for_product.pop(user_tg_id)

    async with async_session_maker() as session:
        res = await session.execute(
            select(User).where(User.tg_id == user_tg_id),
        )
        user = res.scalar_one_or_none()
        if user is None:
            await message.answer("Пользователь не найден, отправь /start.")
            return

        res = await session.execute(
            select(Product).where(Product.id == product_id),
        )
        product = res.scalar_one_or_none()
        if product is None:
            await message.answer("Товар не найден, попробуйте ещё раз из каталога.")
            return

        orders_repo = OrdersRepo(session)
        await orders_repo.add_to_cart(
            user=user,
            product=product,
            size=size_text,
            quantity=1,
        )
        await session.commit()

    kb = InlineKeyboardBuilder()
    kb.button(text="📦 Корзина", callback_data="show:cart")
    kb.button(text="🛍 Продолжить покупки", callback_data="back:categories")
    kb.adjust(1)

    await message.answer(
        f"✅ Добавлено в корзину:\n"
        f"{product.title}\n"
        f"Размер: {size_text}",
        reply_markup=kb.as_markup(),
    )






