import os
import openpyxl
from aiogram import Router, types, F, Bot
from aiogram.filters import StateFilter
from groq import Groq

# Инициализируем роутер
router = Router()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL_NAME = "llama-3.3-70b-versatile"

# --- ЕДИНЫЙ МАСТЕР-ОБРАБОТЧИК ---
# Ловит ВСЁ (и текст, и документы), если нет активного режима поиска
@router.message(StateFilter(None))
async def master_handler(message: types.Message, bot: Bot):
    
    # 1. СМОТРИМ, ЕСТЬ ЛИ ФАЙЛ (ДОКУМЕНТ)
    if message.document:
        document = message.document
        file_name = document.file_name.lower()

        # Если это Excel
        if file_name.endswith('.xlsx') or file_name.endswith('.xls'):
            status_msg = await message.answer(f"📝 Вижу смету: {document.file_name}. Читаю...")
            await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
            
            try:
                # Скачиваем
                file_path = f"/tmp/{document.file_name}"
                await bot.download(document, destination=file_path)

                # Читаем через OpenPyXL
                try:
                    wb = openpyxl.load_workbook(file_path, data_only=True)
                    sheet = wb.active
                    
                    data_rows = []
                    row_count = 0
                    for row in sheet.iter_rows(values_only=True):
                        # Собираем строку, пропуская пустые ячейки
                        cleaned_row = [str(cell) if cell is not None else "" for cell in row]
                        if any(cleaned_row): 
                            data_rows.append(" | ".join(cleaned_row))
                            row_count += 1
                        if row_count >= 150: # Читаем первые 150 строк
                            break
                    
                    data_str = "\n".join(data_rows)
                    wb.close()
                except Exception as read_err:
                    await status_msg.edit_text(f"❌ Ошибка структуры Excel: {read_err}")
                    if os.path.exists(file_path): os.remove(file_path)
                    return

                # Чистим мусор
                if os.path.exists(file_path):
                    os.remove(file_path)

                # Если файл пустой
                if not data_str:
                    await status_msg.edit_text("⚠️ Файл пустой или не читается.")
                    return

                # ОТПРАВЛЯЕМ В ЛАМУ
                prompt = (
                    f"Пользователь загрузил смету: {document.file_name}.\n"
                    f"ДАННЫЕ ИЗ ТАБЛИЦЫ:\n{data_str}\n\n"
                    f"ЗАДАЧА: Проанализируй состав работ, цены и объемы. Дай краткое заключение инженера."
                )

                chat_completion = client.chat.completions.create(
                    messages=[
                        {"role": "system", "content": "Ты — Инженер-Сметчик. Анализируй данные."},
                        {"role": "user", "content": prompt}
                    ],
                    model=MODEL_NAME,
                )

                await status_msg.delete()
                await message.answer(f"🏗 **Анализ сметы:**\n\n{chat_completion.choices[0].message.content}")
                return # ВЫХОДИМ ИЗ ФУНКЦИИ, ЧТОБЫ НЕ ОБРАБАТЫВАТЬ КАК ТЕКСТ

            except Exception as e:
                await status_msg.edit_text(f"❌ Общая ошибка: {e}")
                return

    # 2. ЕСЛИ ФАЙЛА НЕТ — ОБРАБАТЫВАЕМ КАК ТЕКСТ
    if message.text:
        user_text = message.text
        # Игнорируем команды (на всякий случай, если попадут сюда)
        if user_text.startswith("/"):
            return

        await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
        try:
            completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": "Ты — Инженер-Помощник. Отвечай на русском языке."},
                    {"role": "user", "content": user_text}
                ],
                model=MODEL_NAME, 
            )
            await message.answer(completion.choices[0].message.content[:4000])
        except Exception as e:
            await message.answer(f"⚠️ Ошибка связи: {e}")