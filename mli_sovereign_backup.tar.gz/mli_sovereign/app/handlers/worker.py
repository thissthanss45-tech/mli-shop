from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from app.config import ALLOWED_USERS, AppMode
# 🔥 ВАЖНО: Импорт функции get_pool
from app.database.connection import get_pool
from app.database.queries import get_user_projects
from app.keyboards.inline import project_select_inline
from app.keyboards.reply import exit_kb

router = Router()

@router.message(F.text == "📝 Внести выполнение")
async def work_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    if not projects: return await message.answer("⚠️ Нет доступных объектов.")
    await state.set_state(AppMode.work_proj_select)
    await message.answer("🏗 Выберите объект:", reply_markup=project_select_inline(projects, "work_proj"))

@router.callback_query(F.data.startswith("work_proj_"))
async def work_proj_chosen(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(proj_id=pid)
    
    # 🔥 ВАЖНО: Используем get_pool()
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT id, work_name, unit, total_qty FROM estimates WHERE project_id = $1 ORDER BY id", pid)
    
    if not rows: return await callback.message.answer("⚠️ Смета пуста.")
    
    text = "📋 **Напишите ID работы:**\n" + "\n".join([f"🆔 **{r['id']}** | {r['work_name']} ({r['total_qty']} {r['unit']})" for r in rows])
    await state.set_state(AppMode.work_item_select)
    await callback.message.answer(text, reply_markup=exit_kb(), parse_mode="Markdown")
    await callback.answer()

@router.message(AppMode.work_item_select)
async def work_item_chosen(message: types.Message, state: FSMContext):
    try: wid = int(message.text)
    except: return await message.answer("⚠️ Введите числовой ID.")
    
    # 🔥 ВАЖНО: Используем get_pool()
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT work_name, unit FROM estimates WHERE id = $1", wid)
    if not row: return await message.answer("⚠️ ID не найден.")
    await state.update_data(work_id=wid, unit=row['unit'])
    await state.set_state(AppMode.work_qty_enter)
    await message.answer(f"📝 **{row['work_name']}**\nСколько выполнено ({row['unit']})?", parse_mode="Markdown")

@router.message(AppMode.work_qty_enter)
async def work_qty_save(message: types.Message, state: FSMContext):
    try: qty = float(message.text.replace(",", "."))
    except: return await message.answer("⚠️ Введите число.")
    data = await state.get_data()
    
    # 🔥 ВАЖНО: Используем get_pool()
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO progress (estimate_id, user_id, qty_done) VALUES ($1, $2, $3)", data['work_id'], message.from_user.id, qty)
    await message.answer(f"✅ Принято: {qty} {data['unit']}", reply_markup=exit_kb())
    await state.set_state(AppMode.work_item_select)

@router.message(F.text == "📜 История / Отмена")
async def history_start(message: types.Message):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    await message.answer("🏗 Выберите объект:", reply_markup=project_select_inline(projects, "hist_proj"))

@router.callback_query(F.data.startswith("hist_proj_"))
async def history_show(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    
    # 🔥 ВАЖНО: Используем get_pool()
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT p.id, p.date, p.qty_done, p.user_id, e.unit, e.work_name, u.username 
            FROM progress p 
            JOIN estimates e ON p.estimate_id = e.id 
            LEFT JOIN users u ON p.user_id = u.telegram_id 
            WHERE e.project_id = $1 
            ORDER BY p.date DESC LIMIT 10
        """, pid)
    
    if not rows: return await callback.message.answer("📭 История пуста.")
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    msg_text = "📜 **Последние записи:**\n\n"
    for r in rows:
        user_name = r['username'] or str(r['user_id'])
        msg_text += f"🔹 {r['work_name']}: {r['qty_done']} {r['unit']}\n👤 {user_name} ({r['date'].strftime('%d.%m')})\n"
        builder.button(text=f"🗑 Отмена {r['qty_done']}", callback_data=f"del_progress_{r['id']}")
    builder.adjust(1)
    await callback.message.answer(msg_text, reply_markup=builder.as_markup(), parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("del_progress_"))
async def del_prog(callback: types.CallbackQuery):
    rid = int(callback.data.split("_")[-1])
    
    # 🔥 ВАЖНО: Используем get_pool()
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM progress WHERE id=$1", rid)
    await callback.message.answer("✅ Удалено.")
    await callback.answer()