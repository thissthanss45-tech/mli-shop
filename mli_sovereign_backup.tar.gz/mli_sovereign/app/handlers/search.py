import os
from aiogram import Router, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from tavily import TavilyClient

# Важно: название переменной роутера
search_router = Router()

class SearchStates(StatesGroup):
    waiting_for_query = State()

# Твой ключ Tavily
TAVILY_KEY = "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"
tavily_client = TavilyClient(api_key=TAVILY_KEY)

# 🔥 ИСПРАВЛЕНИЕ: Ловим любое сообщение, содержащее "поиск" (регистр не важен)
# Это гарантирует, что кнопка сработает, даже если там есть лишние пробелы или смайлики
@search_router.message(F.text.lower().contains("поиск"))
async def start_search_mode(message: types.Message, state: FSMContext):
    await state.set_state(SearchStates.waiting_for_query)
    await message.answer("🌐 <b>Режим поиска (Google).</b>\nВведите ваш запрос:", parse_mode="HTML")

# 2. Ловим сам запрос (когда бот ждет ввода)
@search_router.message(SearchStates.waiting_for_query)
async def execute_search(message: types.Message, state: FSMContext):
    query = message.text
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")

    try:
        response = tavily_client.search(query=query, search_depth="basic", max_results=5)
        results = response.get('results', [])

        if not results:
            await message.answer("Ничего не найдено.")
        else:
            output_text = f"🔎 <b>Результаты:</b> {query}\n\n"
            for res in results:
                title = res.get('title', 'Link')
                url = res.get('url', '#')
                output_text += f"🔹 <a href='{url}'>{title}</a>\n\n"
            
            await message.answer(output_text, parse_mode="HTML", disable_web_page_preview=True)

    except Exception as e:
        await message.answer(f"Ошибка: {e}")

    await state.clear()