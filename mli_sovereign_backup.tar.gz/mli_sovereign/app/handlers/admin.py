from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from app.config import ALLOWED_USERS, ADMIN_ID, AppMode
# 🔥 ИСПОЛЬЗУЕМ get_pool
from app.database.connection import get_pool
from app.database.queries import get_user_projects
from app.keyboards.inline import project_select_inline, my_projects_kb, access_type_kb, confirm_delete_kb
from app.keyboards.reply import dashboard_kb, exit_kb

router = Router()

@router.message(F.text == "🏗 Мои Объекты")
async def mode_projects(message: types.Message):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    is_admin = (message.from_user.id == ADMIN_ID)
    await message.answer("🏗 **Управление объектами:**", reply_markup=my_projects_kb(projects, is_admin))

@router.callback_query(F.data.startswith("switch_proj_"))
async def switch_project(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("UPDATE users SET current_project_id = $1 WHERE telegram_id = $2", pid, callback.from_user.id)
        name = await conn.fetchval("SELECT name FROM projects WHERE id=$1", pid)
    await callback.message.answer(f"✅ Активный сектор: **{name}**")
    await callback.answer()

@router.callback_query(F.data == "create_new_project")
async def create_proj_start(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AppMode.project_create_name)
    await callback.message.answer("🆕 Введите название нового объекта:", reply_markup=exit_kb())
    await callback.answer()

@router.message(AppMode.project_create_name)
async def create_proj_finish(message: types.Message, state: FSMContext):
    pool = await get_pool()
    async with pool.acquire() as conn:
        pid = await conn.fetchval("INSERT INTO projects (name) VALUES ($1) RETURNING id", message.text)
        await conn.execute("INSERT INTO project_access (project_id, user_id) VALUES ($1, $2)", pid, ADMIN_ID)
    await message.answer(f"✅ Объект **{message.text}** создан!", reply_markup=dashboard_kb())
    await state.clear()

@router.callback_query(F.data == "delete_project_start")
async def del_proj_start(callback: types.CallbackQuery):
    projects = await get_user_projects(callback.from_user.id)
    await callback.message.answer("🗑 Что удаляем?", reply_markup=project_select_inline(projects, "ask_del"))
    await callback.answer()

@router.callback_query(F.data.startswith("ask_del_"))
async def del_proj_ask(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    await callback.message.answer(f"⛔️ Удалить объект и все данные?", reply_markup=confirm_delete_kb(pid))
    await callback.answer()

@router.callback_query(F.data == "cancel_del")
async def del_cancel(callback: types.CallbackQuery):
    await callback.message.delete()

@router.callback_query(F.data.startswith("confirm_del_"))
async def del_confirm(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM progress WHERE estimate_id IN (SELECT id FROM estimates WHERE project_id=$1)", pid)
        await conn.execute("DELETE FROM estimates WHERE project_id=$1", pid)
        await conn.execute("DELETE FROM projects WHERE id=$1", pid)
    await callback.message.answer("🗑 Объект удален.")
    await callback.answer()

@router.callback_query(F.data == "access_manage_start")
async def access_start(callback: types.CallbackQuery):
    projects = await get_user_projects(callback.from_user.id)
    await callback.message.answer("👥 Выберите проект:", reply_markup=project_select_inline(projects, "access_sel"))
    await callback.answer()

@router.callback_query(F.data.startswith("access_sel_"))
async def access_type_choose(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    pool = await get_pool()
    async with pool.acquire() as conn:
        name = await conn.fetchval("SELECT name FROM projects WHERE id=$1", pid)
    await callback.message.answer(f"🛠 **{name}**", reply_markup=access_type_kb(pid))
    await callback.answer()

@router.callback_query(F.data.startswith("access_add_"))
async def access_add_input(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(access_pid=pid)
    await state.set_state(AppMode.add_user_input)
    await callback.message.answer("👤 Введите ID сотрудника:", reply_markup=exit_kb())
    await callback.answer()

@router.message(AppMode.add_user_input)
async def access_add_finish(message: types.Message, state: FSMContext):
    try: target_id = int(message.text)
    except: return await message.answer("⚠️ Нужны цифры.")
    data = await state.get_data()
    pool = await get_pool()
    async with pool.acquire() as conn:
        user_exists = await conn.fetchval("SELECT telegram_id FROM users WHERE telegram_id = $1", target_id)
        if not user_exists: await conn.execute("INSERT INTO users (telegram_id, username) VALUES ($1, 'Unknown') ON CONFLICT DO NOTHING", target_id)
        await conn.execute("INSERT INTO project_access (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", data['access_pid'], target_id)
    await message.answer(f"✅ Сотрудник {target_id} добавлен.", reply_markup=dashboard_kb())
    await state.clear()

@router.callback_query(F.data.startswith("access_rem_"))
async def access_rem_select(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(access_pid=pid)
    pool = await get_pool()
    async with pool.acquire() as conn:
        users = await conn.fetch("SELECT u.telegram_id, u.username FROM users u JOIN project_access pa ON u.telegram_id = pa.user_id WHERE pa.project_id = $1 AND u.telegram_id != $2", pid, ADMIN_ID)
    if not users: return await callback.message.answer("🤷‍♂️ Тут только вы.")
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    for u in users:
        builder.button(text=f"❌ {u['username'] or u['telegram_id']}", callback_data=f"kick_{u['telegram_id']}")
    builder.adjust(1)
    await callback.message.answer("🚫 Кого убрать?", reply_markup=builder.as_markup())
    await callback.answer()

@router.callback_query(F.data.startswith("kick_"))
async def access_kick_finish(callback: types.CallbackQuery, state: FSMContext):
    target_id = int(callback.data.split("_")[-1])
    data = await state.get_data()
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM project_access WHERE project_id = $1 AND user_id = $2", data['access_pid'], target_id)
    await callback.message.answer(f"✅ Удален.")
    await callback.answer()