from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from app.config import ALLOWED_USERS, ADMIN_ID
# 🔥 ИСПОЛЬЗУЕМ get_pool
from app.database.connection import get_pool
from app.keyboards.reply import dashboard_kb, main_menu_kb

router = Router()

@router.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    
    role = 'admin' if message.from_user.id == ADMIN_ID else 'worker'
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO users (telegram_id, username, role) VALUES ($1, $2, $3) ON CONFLICT (telegram_id) DO UPDATE SET username = $2", message.from_user.id, message.from_user.username, role)
        if message.from_user.id == ADMIN_ID:
            await conn.execute("UPDATE users SET role = 'admin' WHERE telegram_id = $1", ADMIN_ID)

    await state.clear()
    await message.answer(f"👷‍♂️ **SaaS System v3.3.1**\nСтатус: В сети\nРоль: {role.upper()}", reply_markup=main_menu_kb())

@router.message(F.text.in_({"☰ ГЛАВНОЕ МЕНЮ", "◀️ Назад в Меню"}))
async def global_exit(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    await state.clear()
    await message.answer("🎛 **Главное меню:**", reply_markup=dashboard_kb())
    