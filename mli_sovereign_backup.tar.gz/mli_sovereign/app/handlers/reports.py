import os
import openpyxl
from aiogram import Router, types, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import FSInputFile
from app.config import ALLOWED_USERS, AppMode
# 🔥 ИСПОЛЬЗУЕМ get_pool
from app.database.connection import get_pool
from app.database.queries import get_user_projects
from app.keyboards.inline import project_select_inline
from app.keyboards.reply import exit_kb

router = Router()

@router.message(F.text == "📊 Отчеты и КС")
async def report_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    await state.set_state(AppMode.report_proj_select)
    await message.answer("📊 Объект для отчета:", reply_markup=project_select_inline(projects, "report_proj"))

@router.callback_query(F.data.startswith("report_proj_"))
async def report_generate(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    await callback.message.answer("⏳ Генерирую...")
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""SELECT e.work_name, e.unit, e.price, e.total_qty, COALESCE(SUM(p.qty_done), 0) as done_sum FROM estimates e LEFT JOIN progress p ON e.id = p.estimate_id WHERE e.project_id = $1 GROUP BY e.id, e.work_name, e.unit, e.price, e.total_qty ORDER BY e.id""", pid)
    
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(["Работа", "Ед.", "Цена", "План", "Факт", "Сумма"])
    total = 0
    for r in rows:
        m = float(r['price']) * float(r['done_sum']); total += m
        ws.append([r['work_name'], r['unit'], r['price'], r['total_qty'], r['done_sum'], m])
    ws.append(["", "", "", "", "ИТОГО:", total])
    
    path = f"app/downloads/Report_{pid}.xlsx"
    if not os.path.exists("app/downloads"): os.makedirs("app/downloads")
    wb.save(path)
    await callback.message.answer_document(FSInputFile(path), caption=f"💰 Итого: {total:,.2f} руб.")
    await callback.answer()

@router.message(F.text == "📂 База Знаний")
async def mode_knowledge(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    await state.set_state(AppMode.estimate_upload)
    await message.answer("📥 Куда грузим смету?", reply_markup=project_select_inline(projects, "upload_proj"))

@router.callback_query(F.data.startswith("upload_proj_"))
async def upload_proj_chosen(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(target_project_id=pid)
    await callback.message.answer("📎 Пришлите Excel...", reply_markup=exit_kb())
    await callback.answer()

@router.message(AppMode.estimate_upload, F.document)
async def process_estimate(message: types.Message, state: FSMContext, bot: Bot):
    path = f"app/downloads/{message.document.file_name}"
    if not os.path.exists("app/downloads"): os.makedirs("app/downloads")
    file = await bot.get_file(message.document.file_id)
    await bot.download_file(file.file_path, path)
    data = await state.get_data()
    
    try:
        wb = openpyxl.load_workbook(path, data_only=True); sheet = wb.active; c = 0
        pool = await get_pool()
        async with pool.acquire() as conn:
            for row in sheet.iter_rows(min_row=2, values_only=True):
                if row[0]:
                    try: price, qty = float(str(row[3]).replace(",", ".") or 0), float(str(row[2]).replace(",", ".") or 0)
                    except: price, qty = 0, 0
                    await conn.execute("INSERT INTO estimates (project_id, work_name, unit, price, total_qty) VALUES ($1, $2, $3, $4, $5)", data['target_project_id'], str(row[0]), str(row[1]), price, qty)
                    c += 1
        await message.answer(f"✅ Загружено строк: {c}")
    except Exception as e:
        await message.answer(f"⚠️ Ошибка Excel: {e}")
    await state.clear()