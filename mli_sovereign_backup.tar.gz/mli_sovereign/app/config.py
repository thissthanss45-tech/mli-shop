import os
import logging
from aiogram.fsm.state import State, StatesGroup
from dotenv import load_dotenv

logging.basicConfig(level=logging.INFO)
load_dotenv()

# --- КЛЮЧИ ---
TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = 1200382005 
ALLOWED_USERS = [1200382005, 8015307297]

DB_USER = os.getenv("POSTGRES_USER")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD")
DB_NAME = os.getenv("POSTGRES_DB")
DB_HOST = "db"

GROQ_KEY = os.getenv("GROQ_API_KEY", "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")
TAVILY_KEY = os.getenv("TAVILY_API_KEY", "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")

# --- ГЛОБАЛЬНАЯ ПАМЯТЬ ---
CHAT_MEMORY = {}

# --- СОСТОЯНИЯ (FSM) ---
class AppMode(StatesGroup):
    menu = State()
    ai_engineer = State()
    web_search = State()
    estimate_upload = State()
    work_proj_select = State()
    work_item_select = State()
    work_qty_enter = State()
    project_create_name = State()
    report_proj_select = State()
    add_user_input = State()
    access_proj_select = State()