from aiogram.utils.keyboard import InlineKeyboardBuilder

def project_select_inline(projects_list, prefix):
    builder = InlineKeyboardBuilder()
    for p in projects_list:
        builder.button(text=f"🏗 {p['name']}", callback_data=f"{prefix}_{p['id']}")
    builder.adjust(1)
    return builder.as_markup()

def my_projects_kb(projects_list, is_admin):
    builder = InlineKeyboardBuilder()
    for p in projects_list:
        builder.button(text=f"🏗 {p['name']}", callback_data=f"switch_proj_{p['id']}")
    if is_admin:
        builder.button(text="➕ СОЗДАТЬ ПРОЕКТ", callback_data="create_new_project")
        builder.button(text="👥 УПРАВЛЕНИЕ ДОСТУПОМ", callback_data="access_manage_start")
        builder.button(text="🗑 УДАЛИТЬ ПРОЕКТ", callback_data="delete_project_start")
    builder.adjust(1)
    return builder.as_markup()

def access_type_kb(proj_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Добавить", callback_data=f"access_add_{proj_id}")
    builder.button(text="❌ Удалить", callback_data=f"access_rem_{proj_id}")
    return builder.as_markup()

def confirm_delete_kb(proj_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ ДА, УДАЛИТЬ", callback_data=f"confirm_del_{proj_id}")
    builder.button(text="❌ ОТМЕНА", callback_data="cancel_del")
    return builder.as_markup()