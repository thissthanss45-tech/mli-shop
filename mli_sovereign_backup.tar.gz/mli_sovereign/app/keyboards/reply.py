from aiogram.utils.keyboard import ReplyKeyboardBuilder

def dashboard_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="📝 Внести выполнение")
    builder.button(text="🏗 Мои Объекты")
    builder.button(text="📜 История / Отмена")
    builder.button(text="📊 Отчеты и КС")
    builder.button(text="📂 База Знаний")
    builder.button(text="🧠 Инженер-Помощник")
    builder.button(text="🌐 Поиск (Без ИИ)")
    builder.adjust(2, 2, 2, 1)
    return builder.as_markup(resize_keyboard=True)

def exit_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="◀️ Назад в Меню")
    builder.button(text="🧹 Забыть диалог")
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)

# ВОТ ЭТОЙ ФУНКЦИИ НЕ ХВАТАЛО 👇
def main_menu_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="☰ ГЛАВНОЕ МЕНЮ")
    return builder.as_markup(resize_keyboard=True)