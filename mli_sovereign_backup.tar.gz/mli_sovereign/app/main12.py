import asyncio
import logging
import os
import asyncpg
import PyPDF2
import openpyxl
from openpyxl.styles import Font
import docx
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import FSInputFile
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from dotenv import load_dotenv
from groq import Groq
from tavily import TavilyClient

# --- НАСТРОЙКИ СИСТЕМЫ ---
logging.basicConfig(level=logging.INFO)
load_dotenv()

TOKEN = os.getenv("BOT_TOKEN")
DB_USER = os.getenv("POSTGRES_USER")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD")
DB_NAME = os.getenv("POSTGRES_DB")
DB_HOST = "db"
# Используем ключи из ENV или запасные (твои)
GROQ_KEY = os.getenv("GROQ_API_KEY", "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")
TAVILY_KEY = os.getenv("TAVILY_API_KEY", "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")

ADMIN_ID = 1200382005 
ALLOWED_USERS = [1200382005, 8015307297]

# ГЛОБАЛЬНАЯ ПАМЯТЬ ДИАЛОГОВ
CHAT_MEMORY = {}

bot = Bot(token=TOKEN)
dp = Dispatcher()
db_pool = None

groq_client = Groq(api_key=GROQ_KEY)
tavily_client = TavilyClient(api_key=TAVILY_KEY)

# --- 🚦 СОСТОЯНИЯ (FSM) ---
class AppMode(StatesGroup):
    menu = State()
    ai_engineer = State()
    web_search = State()
    estimate_project_select = State()
    estimate_upload = State()
    work_proj_select = State()
    work_item_select = State()
    work_qty_enter = State()
    project_create_name = State()
    history_proj_select = State()
    report_proj_select = State()
    access_proj_select = State()
    add_user_input = State()
    remove_user_select = State()

# --- 🏗 БАЗА ДАННЫХ ---
async def init_db():
    global db_pool
    while True:
        try:
            db_pool = await asyncpg.create_pool(
                user=DB_USER, password=DB_PASSWORD, database=DB_NAME, host=DB_HOST
            )
            async with db_pool.acquire() as conn:
                await conn.execute("""CREATE TABLE IF NOT EXISTS users (telegram_id BIGINT PRIMARY KEY, username TEXT, role TEXT DEFAULT 'worker', current_project_id INT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);""")
                await conn.execute("""CREATE TABLE IF NOT EXISTS projects (id SERIAL PRIMARY KEY, name TEXT NOT NULL, address TEXT, status TEXT DEFAULT 'active');""")
                await conn.execute("""CREATE TABLE IF NOT EXISTS estimates (id SERIAL PRIMARY KEY, project_id INT REFERENCES projects(id), work_name TEXT NOT NULL, unit TEXT, price DECIMAL(10,2), total_qty DECIMAL(10,2));""")
                await conn.execute("""CREATE TABLE IF NOT EXISTS progress (id SERIAL PRIMARY KEY, estimate_id INT REFERENCES estimates(id) ON DELETE CASCADE, user_id BIGINT REFERENCES users(telegram_id), qty_done DECIMAL(10,2), date TIMESTAMP DEFAULT CURRENT_TIMESTAMP);""")
                await conn.execute("""CREATE TABLE IF NOT EXISTS project_access (project_id INT REFERENCES projects(id) ON DELETE CASCADE, user_id BIGINT, PRIMARY KEY (project_id, user_id));""")
                await conn.execute("INSERT INTO projects (id, name, address) VALUES (1, 'ЖК Пилотный', 'ул. Тестовая 1') ON CONFLICT DO NOTHING;")
                await conn.execute("UPDATE users SET role = 'admin' WHERE telegram_id = $1", ADMIN_ID)
            logging.info("✅ SaaS v3.3 Connected!")
            return
        except Exception as e:
            logging.error(f"DB Error: {e}")
            await asyncio.sleep(5)

# --- 🛠 HELPERS ---
async def get_user_projects(user_id):
    async with db_pool.acquire() as conn:
        role = await conn.fetchval("SELECT role FROM users WHERE telegram_id = $1", user_id)
        if role == 'admin' or user_id == ADMIN_ID:
            return await conn.fetch("SELECT id, name FROM projects ORDER BY id")
        else:
            return await conn.fetch("SELECT p.id, p.name FROM projects p JOIN project_access pa ON p.id = pa.project_id WHERE pa.user_id = $1 ORDER BY p.id", user_id)

async def safe_send(message: types.Message, text: str, parse_mode="Markdown"):
    if len(text) > 4000:
        for x in range(0, len(text), 4000):
            try: await message.answer(text[x:x+4000], parse_mode=parse_mode, disable_web_page_preview=True)
            except: await message.answer(text[x:x+4000], parse_mode=None, disable_web_page_preview=True)
    else:
        try: await message.answer(text, parse_mode=parse_mode, disable_web_page_preview=True)
        except: await message.answer(text, parse_mode=None, disable_web_page_preview=True)

# --- 🧠 AI С ПАМЯТЬЮ ---
async def ai_response_with_memory(user_id, prompt, context=""):
    history = CHAT_MEMORY.get(user_id, [])
    system_msg = {"role": "system", "content": "Ты — Главный Инженер ПТО. Ты помнишь контекст беседы. Отвечай кратко и по делу."}
    user_content = prompt
    if context: user_content += f"\n\n📄 [ДАННЫЕ ИЗ ФАЙЛА]:\n{context}"
    current_msg = {"role": "user", "content": user_content}
    messages_to_send = [system_msg] + history[-6:] + [current_msg]
    try:
        completion = groq_client.chat.completions.create(model="llama-3.3-70b-versatile", messages=messages_to_send, temperature=0.3)
        answer = completion.choices[0].message.content
        history.append(current_msg); history.append({"role": "assistant", "content": answer})
        if len(history) > 20: history = history[-10:]
        CHAT_MEMORY[user_id] = history
        return answer
    except Exception as e: return f"Ошибка ИИ: {e}"

async def search_response(query):
    try:
        res = tavily_client.search(query=query, max_results=5)
        return "\n".join([f"🔹 {r['title']}\n🔗 {r['url']}\n" for r in res['results']])
    except Exception as e: return f"Ошибка Поиска: {e}"

# --- ⌨️ UI ---
def main_menu_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="☰ ГЛАВНОЕ МЕНЮ")
    return builder.as_markup(resize_keyboard=True)

def dashboard_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="📝 Внести выполнение")
    builder.button(text="🏗 Мои Объекты")
    builder.button(text="📜 История / Отмена")
    builder.button(text="📊 Отчеты и КС")
    builder.button(text="📂 База Знаний")
    builder.button(text="🧠 Инженер-Помощник")
    builder.button(text="🌐 Поиск (Без ИИ)")
    builder.adjust(2, 2, 2, 1)
    return builder.as_markup(resize_keyboard=True)

def exit_kb():
    builder = ReplyKeyboardBuilder()
    builder.button(text="◀️ Назад в Меню")
    builder.button(text="🧹 Забыть диалог") 
    builder.adjust(1)
    return builder.as_markup(resize_keyboard=True)

def project_select_inline(projects_list, prefix):
    builder = InlineKeyboardBuilder()
    for p in projects_list:
        builder.button(text=f"🏗 {p['name']}", callback_data=f"{prefix}_{p['id']}")
    return builder.as_markup()

def my_projects_kb(projects_list, is_admin):
    builder = InlineKeyboardBuilder()
    for p in projects_list:
        builder.button(text=f"🏗 {p['name']}", callback_data=f"switch_proj_{p['id']}")
    if is_admin:
        builder.button(text="➕ СОЗДАТЬ ПРОЕКТ", callback_data="create_new_project")
        builder.button(text="👥 УПРАВЛЕНИЕ ДОСТУПОМ", callback_data="access_manage_start")
        builder.button(text="🗑 УДАЛИТЬ ПРОЕКТ", callback_data="delete_project_start")
    builder.adjust(1)
    return builder.as_markup()

def access_type_kb(proj_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Добавить", callback_data=f"access_add_{proj_id}")
    builder.button(text="❌ Удалить", callback_data=f"access_rem_{proj_id}")
    return builder.as_markup()

def confirm_delete_kb(proj_id):
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ ДА, УДАЛИТЬ", callback_data=f"confirm_del_{proj_id}")
    builder.button(text="❌ ОТМЕНА", callback_data="cancel_del")
    return builder.as_markup()

# --- 🕹 LOGIC ---

@dp.message(F.text == "🧹 Забыть диалог")
async def clear_memory(message: types.Message):
    CHAT_MEMORY[message.from_user.id] = []
    await message.answer("🧹 **Память очищена.** Я забыл, о чем мы говорили. Начинаем с чистого листа.")

@dp.message(F.text.in_({"☰ ГЛАВНОЕ МЕНЮ", "◀️ Назад в Меню"}))
async def global_exit(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    await state.clear()
    await message.answer("🎛 **Пульт Управления:**", reply_markup=dashboard_kb())

@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    role = 'admin' if message.from_user.id == ADMIN_ID else 'worker'
    if db_pool:
        async with db_pool.acquire() as conn:
            await conn.execute("INSERT INTO users (telegram_id, username, role) VALUES ($1, $2, $3) ON CONFLICT (telegram_id) DO UPDATE SET username = $2", message.from_user.id, message.from_user.username, role)
            if message.from_user.id == ADMIN_ID: await conn.execute("UPDATE users SET role = 'admin' WHERE telegram_id = $1", ADMIN_ID)
    await state.clear()
    await message.answer(f"👷‍♂️ **SaaS v3.3**\nРоль: {role.upper()}", reply_markup=main_menu_kb())

# --- 1. ПРОЕКТЫ И УПРАВЛЕНИЕ ---
@dp.message(F.text == "🏗 Мои Объекты")
async def mode_projects(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    is_admin = (message.from_user.id == ADMIN_ID)
    await message.answer("🏗 **Объекты / Сектора:**", reply_markup=my_projects_kb(projects, is_admin))

@dp.callback_query(F.data.startswith("switch_proj_"))
async def switch_project(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    async with db_pool.acquire() as conn:
        await conn.execute("UPDATE users SET current_project_id = $1 WHERE telegram_id = $2", pid, callback.from_user.id)
        name = await conn.fetchval("SELECT name FROM projects WHERE id=$1", pid)
    await callback.message.answer(f"✅ Активный сектор: **{name}**")
    await callback.answer()

@dp.callback_query(F.data == "create_new_project")
async def create_proj_start(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AppMode.project_create_name)
    await callback.message.answer("🆕 Название Сектора:", reply_markup=exit_kb())
    await callback.answer()

@dp.message(AppMode.project_create_name)
async def create_proj_finish(message: types.Message, state: FSMContext):
    async with db_pool.acquire() as conn:
        pid = await conn.fetchval("INSERT INTO projects (name) VALUES ($1) RETURNING id", message.text)
        await conn.execute("INSERT INTO project_access (project_id, user_id) VALUES ($1, $2)", pid, ADMIN_ID)
    await message.answer(f"✅ Проект **{message.text}** создан!", reply_markup=dashboard_kb())
    await state.clear()

@dp.callback_query(F.data == "delete_project_start")
async def del_proj_start(callback: types.CallbackQuery):
    projects = await get_user_projects(callback.from_user.id)
    await callback.message.answer("🗑 Удалить:", reply_markup=project_select_inline(projects, "ask_del"))
    await callback.answer()

@dp.callback_query(F.data.startswith("ask_del_"))
async def del_proj_ask(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    await callback.message.answer(f"⛔️ Удалить ID {pid}?", reply_markup=confirm_delete_kb(pid))
    await callback.answer()

@dp.callback_query(F.data == "cancel_del")
async def del_cancel(callback: types.CallbackQuery):
    await callback.message.delete()

@dp.callback_query(F.data.startswith("confirm_del_"))
async def del_confirm(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    async with db_pool.acquire() as conn:
        await conn.execute("DELETE FROM progress WHERE estimate_id IN (SELECT id FROM estimates WHERE project_id=$1)", pid)
        await conn.execute("DELETE FROM estimates WHERE project_id=$1", pid)
        await conn.execute("DELETE FROM projects WHERE id=$1", pid)
    await callback.message.answer("🗑 Удалено.")
    await callback.answer()

@dp.callback_query(F.data == "access_manage_start")
async def access_start(callback: types.CallbackQuery):
    projects = await get_user_projects(callback.from_user.id)
    await callback.message.answer("👥 Выберите проект:", reply_markup=project_select_inline(projects, "access_sel"))
    await callback.answer()

@dp.callback_query(F.data.startswith("access_sel_"))
async def access_type_choose(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    async with db_pool.acquire() as conn:
        name = await conn.fetchval("SELECT name FROM projects WHERE id=$1", pid)
    await callback.message.answer(f"🛠 **{name}**", reply_markup=access_type_kb(pid))
    await callback.answer()

@dp.callback_query(F.data.startswith("access_add_"))
async def access_add_input(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(access_pid=pid)
    await state.set_state(AppMode.add_user_input)
    await callback.message.answer("👤 Введите ID сотрудника:", reply_markup=exit_kb())
    await callback.answer()

@dp.message(AppMode.add_user_input)
async def access_add_finish(message: types.Message, state: FSMContext):
    try: target_id = int(message.text)
    except: return await message.answer("⚠️ Нужны цифры.")
    data = await state.get_data()
    async with db_pool.acquire() as conn:
        user_exists = await conn.fetchval("SELECT telegram_id FROM users WHERE telegram_id = $1", target_id)
        if not user_exists: await conn.execute("INSERT INTO users (telegram_id, username) VALUES ($1, 'Unknown') ON CONFLICT DO NOTHING", target_id)
        await conn.execute("INSERT INTO project_access (project_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", data['access_pid'], target_id)
    await message.answer(f"✅ Сотрудник {target_id} добавлен.", reply_markup=dashboard_kb())
    await state.clear()

@dp.callback_query(F.data.startswith("access_rem_"))
async def access_rem_select(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(access_pid=pid)
    async with db_pool.acquire() as conn:
        users = await conn.fetch("SELECT u.telegram_id, u.username FROM users u JOIN project_access pa ON u.telegram_id = pa.user_id WHERE pa.project_id = $1 AND u.telegram_id != $2", pid, ADMIN_ID)
    if not users: return await callback.message.answer("🤷‍♂️ Тут только вы.")
    builder = InlineKeyboardBuilder()
    for u in users:
        builder.button(text=f"❌ {u['username'] or u['telegram_id']}", callback_data=f"kick_{u['telegram_id']}")
    builder.adjust(1)
    await callback.message.answer("🚫 Кого убрать?", reply_markup=builder.as_markup())
    await callback.answer()

@dp.callback_query(F.data.startswith("kick_"))
async def access_kick_finish(callback: types.CallbackQuery, state: FSMContext):
    target_id = int(callback.data.split("_")[-1])
    data = await state.get_data()
    async with db_pool.acquire() as conn:
        await conn.execute("DELETE FROM project_access WHERE project_id = $1 AND user_id = $2", data['access_pid'], target_id)
    await callback.message.answer(f"✅ Удален.")
    await callback.answer()

# --- 2. ВНЕСЕНИЕ ВЫПОЛНЕНИЯ ---
@dp.message(F.text == "📝 Внести выполнение")
async def work_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    if not projects: return await message.answer("⚠️ Нет объектов.")
    await state.set_state(AppMode.work_proj_select)
    await message.answer("🏗 Объект:", reply_markup=project_select_inline(projects, "work_proj"))

@dp.callback_query(F.data.startswith("work_proj_"))
async def work_proj_chosen(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(proj_id=pid)
    async with db_pool.acquire() as conn:
        rows = await conn.fetch("SELECT id, work_name, unit, total_qty FROM estimates WHERE project_id = $1 ORDER BY id", pid)
    if not rows: return await callback.message.answer("⚠️ Смета пуста.")
    text = "📋 **Напишите ID:**\n" + "\n".join([f"🆔 **{r['id']}** | {r['work_name']} ({r['total_qty']} {r['unit']})" for r in rows])
    await state.set_state(AppMode.work_item_select)
    await callback.message.answer(text, reply_markup=exit_kb(), parse_mode="Markdown")
    await callback.answer()

@dp.message(AppMode.work_item_select)
async def work_item_chosen(message: types.Message, state: FSMContext):
    try: wid = int(message.text)
    except: return await message.answer("⚠️ Нужна цифра.")
    async with db_pool.acquire() as conn:
        row = await conn.fetchrow("SELECT work_name, unit FROM estimates WHERE id = $1", wid)
    if not row: return await message.answer("⚠️ Неверный ID.")
    await state.update_data(work_id=wid, work_name=row['work_name'], unit=row['unit'])
    await state.set_state(AppMode.work_qty_enter)
    await message.answer(f"📝 **{row['work_name']}**\nСколько сделали ({row['unit']})?", parse_mode="Markdown")

@dp.message(AppMode.work_qty_enter)
async def work_qty_save(message: types.Message, state: FSMContext):
    try: qty = float(message.text.replace(",", "."))
    except: return await message.answer("⚠️ Нужно число.")
    data = await state.get_data()
    async with db_pool.acquire() as conn:
        await conn.execute("INSERT INTO progress (estimate_id, user_id, qty_done) VALUES ($1, $2, $3)", data['work_id'], message.from_user.id, qty)
    await message.answer(f"✅ Принято: {qty} {data['unit']}", reply_markup=exit_kb())
    await state.set_state(AppMode.work_item_select)

# --- 3. ИСТОРИЯ (ИСПРАВЛЕНО) ---
@dp.message(F.text == "📜 История / Отмена")
async def history_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    if not projects: return await message.answer("⚠️ Нет объектов.")
    await message.answer("🏗 Выберите объект:", reply_markup=project_select_inline(projects, "hist_proj"))

@dp.callback_query(F.data.startswith("hist_proj_"))
async def history_show(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    async with db_pool.acquire() as conn:
        # 🔥 ИСПРАВЛЕНИЕ: ДОБАВЛЕНО ПОЛЕ p.user_id В ЗАПРОС
        rows = await conn.fetch("""
            SELECT p.id, p.date, p.qty_done, p.user_id, e.unit, e.work_name, u.username 
            FROM progress p 
            JOIN estimates e ON p.estimate_id = e.id 
            LEFT JOIN users u ON p.user_id = u.telegram_id 
            WHERE e.project_id = $1 
            ORDER BY p.date DESC LIMIT 8
        """, pid)
    
    if not rows: return await callback.message.answer("📭 История пуста.")
    
    builder = InlineKeyboardBuilder()
    msg_text = "📜 **Последние записи:**\n\n"
    for r in rows:
        # Теперь эта строка не вызовет ошибку, так как p.user_id есть в ответе базы
        user_name = r['username'] or str(r['user_id'])
        msg_text += f"🔹 {r['work_name']}: {r['qty_done']} {r['unit']}\n👤 {user_name} ({r['date'].strftime('%d.%m')})\n"
        builder.button(text=f"🗑 Удалить {r['qty_done']} {r['unit']}", callback_data=f"del_progress_{r['id']}")
    
    builder.adjust(1)
    await callback.message.answer(msg_text, reply_markup=builder.as_markup(), parse_mode="Markdown")
    await callback.answer()

@dp.callback_query(F.data.startswith("del_progress_"))
async def del_prog(callback: types.CallbackQuery):
    rid = int(callback.data.split("_")[-1])
    async with db_pool.acquire() as conn:
        await conn.execute("DELETE FROM progress WHERE id=$1", rid)
    await callback.message.answer("✅ Удалено.")
    await callback.answer()

# --- 4. ОТЧЕТЫ ---
@dp.message(F.text == "📊 Отчеты и КС")
async def report_start(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    if not projects: return await message.answer("⚠️ Нет объектов.")
    await state.set_state(AppMode.report_proj_select)
    await message.answer("📊 Выберите объект:", reply_markup=project_select_inline(projects, "report_proj"))

@dp.callback_query(F.data.startswith("report_proj_"))
async def report_generate(callback: types.CallbackQuery):
    pid = int(callback.data.split("_")[-1])
    await callback.message.answer("⏳ Считаю...")
    async with db_pool.acquire() as conn:
        rows = await conn.fetch("""SELECT e.work_name, e.unit, e.price, e.total_qty, COALESCE(SUM(p.qty_done), 0) as done_sum FROM estimates e LEFT JOIN progress p ON e.id = p.estimate_id WHERE e.project_id = $1 GROUP BY e.id, e.work_name, e.unit, e.price, e.total_qty ORDER BY e.id""", pid)
        proj_name = await conn.fetchval("SELECT name FROM projects WHERE id=$1", pid)
    if not rows: return await callback.message.answer("⚠️ Смета пуста.")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["Наименование", "Ед.", "Цена", "План", "Факт", "Остаток", "Сумма"])
    total_money = 0
    for r in rows:
        plan, fact = float(r['total_qty']), float(r['done_sum'])
        price = float(r['price'])
        money = price * fact
        total_money += money
        ws.append([r['work_name'], r['unit'], price, plan, fact, plan-fact, money])
    ws.append(["", "", "", "", "", "ИТОГО:", total_money])
    filename = f"downloads/Otchet_{pid}.xlsx"
    if not os.path.exists("downloads"): os.makedirs("downloads")
    wb.save(filename)
    file = FSInputFile(filename, filename=f"Отчет_{proj_name}.xlsx")
    await callback.message.answer_document(file, caption=f"💰 Итого: **{total_money:,.2f} руб.**")
    await callback.answer()

# --- 5. ЗАГРУЗКА СМЕТЫ ---
@dp.message(F.text == "📂 База Знаний")
async def mode_knowledge(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    projects = await get_user_projects(message.from_user.id)
    await state.set_state(AppMode.estimate_upload)
    await message.answer("📥 Куда грузим смету?", reply_markup=project_select_inline(projects, "upload_proj"))

@dp.callback_query(F.data.startswith("upload_proj_"))
async def upload_proj_chosen(callback: types.CallbackQuery, state: FSMContext):
    pid = int(callback.data.split("_")[-1])
    await state.update_data(target_project_id=pid)
    await callback.message.answer("📎 Жду Excel...", reply_markup=exit_kb())
    await callback.answer()

@dp.message(AppMode.estimate_upload, F.document)
async def process_estimate(message: types.Message, state: FSMContext):
    path = f"downloads/{message.document.file_name}"
    file = await bot.get_file(message.document.file_id)
    await bot.download_file(file.file_path, path)
    data = await state.get_data()
    wb = openpyxl.load_workbook(path, data_only=True)
    sheet = wb.active
    c = 0
    async with db_pool.acquire() as conn:
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if row[0]:
                try: price, qty = float(str(row[3]).replace(",", ".") or 0), float(str(row[2]).replace(",", ".") or 0)
                except: price, qty = 0, 0
                await conn.execute("INSERT INTO estimates (project_id, work_name, unit, price, total_qty) VALUES ($1, $2, $3, $4, $5)", data['target_project_id'], str(row[0]), str(row[1]), price, qty)
                c += 1
    await message.answer(f"✅ Загружено: {c}")
    await state.clear()

# --- 6. ИНЖЕНЕР + ПОИСК ---
@dp.message(F.text == "🧠 Инженер-Помощник")
async def mode_ai(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    await state.set_state(AppMode.ai_engineer)
    await message.answer("🧠 Задайте вопрос или пришлите файл", reply_markup=exit_kb())

@dp.message(AppMode.ai_engineer)
async def process_ai_chat(message: types.Message):
    if message.text == "🧹 Забыть диалог": # Перехват кнопки
        CHAT_MEMORY[message.from_user.id] = []
        return await message.answer("🧹 Контекст очищен.")

    if message.document:
        path = f"downloads/{message.document.file_name}"
        file = await bot.get_file(message.document.file_id)
        await bot.download_file(file.file_path, path)
        content = ""
        try:
            if path.endswith(".pdf"): content = PyPDF2.PdfReader(path).pages[0].extract_text()
            elif path.endswith(".docx"): content = "\n".join([p.text for p in docx.Document(path).paragraphs])
            # Отправляем в ИИ с памятью
            ans = await ai_response_with_memory(message.from_user.id, f"Проанализируй файл {message.document.file_name}", content[:3000])
            await safe_send(message, ans)
        except: await message.answer("⚠️ Ошибка файла.")
        return
        
    await bot.send_chat_action(message.chat.id, "typing")
    if message.text and any(w in message.text.lower() for w in ["найди", "поиск", "цена"]):
        res = await search_response(message.text)
        await safe_send(message, f"Вопрос: {message.text}\n{res}", parse_mode=None)
    else:
        # Используем новую функцию с памятью
        ans = await ai_response_with_memory(message.from_user.id, message.text)
        await safe_send(message, ans)

@dp.message(F.text == "🌐 Поиск (Без ИИ)")
async def mode_search(message: types.Message, state: FSMContext):
    if message.from_user.id not in ALLOWED_USERS: return
    await state.set_state(AppMode.web_search)
    await message.answer("🌐 Введите запрос:", reply_markup=exit_kb())

@dp.message(AppMode.web_search)
async def process_search(message: types.Message):
    await bot.send_chat_action(message.chat.id, "typing")
    res = await search_response(message.text)
    await safe_send(message, res, parse_mode=None)

async def main():
    await init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())