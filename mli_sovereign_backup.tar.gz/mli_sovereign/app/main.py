import asyncio
import logging
import sys
import os

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

# Получаем токен
TOKEN = os.getenv("BOT_TOKEN")

# --- ПРЯМЫЕ ИМПОРТЫ (Чобы не зависеть от __init__.py) ---
# Подключаем модули напрямую из файлов
from app.handlers.common import router as common_router
from app.handlers.admin import router as admin_router
from app.handlers.worker import router as worker_router
from app.handlers.reports import router as reports_router
from app.handlers.ai_intel import router as ai_router

# Наш новый поиск
from app.handlers.search import search_router 

from app.database.connection import init_db

async def main():
    # Логирование
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    logging.info("🚀 Starting Bot MLI Sovereign...")

    if not TOKEN:
        logging.error("⛔ TOKEN не найден! Проверь .env")
        return

    # Инициализация
    bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # БД
    await init_db()

    # --- РЕГИСТРАЦИЯ РОУТЕРОВ ---
    # 1. Сначала поиск (чтобы перехватить кнопку)
    dp.include_router(search_router)

    # 2. Основные модули
    dp.include_router(common_router)
    dp.include_router(admin_router)
    dp.include_router(worker_router)
    dp.include_router(reports_router)

    # 3. В конце ИИ (Лама)
    dp.include_router(ai_router)

    # Запуск
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("🛑 Bot stopped")