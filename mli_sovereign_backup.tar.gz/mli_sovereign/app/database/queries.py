# 🔥 ИСПОЛЬЗУЕМ get_pool
from app.database.connection import get_pool
from app.config import ADMIN_ID

async def get_user_projects(user_id):
    pool = await get_pool()
    async with pool.acquire() as conn:
        role = await conn.fetchval("SELECT role FROM users WHERE telegram_id = $1", user_id)
        if role == 'admin' or user_id == ADMIN_ID:
            return await conn.fetch("SELECT id, name FROM projects ORDER BY id")
        else:
            return await conn.fetch("SELECT p.id, p.name FROM projects p JOIN project_access pa ON p.id = pa.project_id WHERE pa.user_id = $1 ORDER BY p.id", user_id)