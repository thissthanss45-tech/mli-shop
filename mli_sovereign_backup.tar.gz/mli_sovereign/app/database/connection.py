import asyncpg
import logging
import asyncio
from app.config import DB_USER, DB_PASSWORD, DB_NAME, DB_HOST, ADMIN_ID

# Глобальная переменная
db_pool = None

async def init_db():
    global db_pool
    # Если пул уже есть и он не закрыт — не создаем новый
    if db_pool and not db_pool._closed:
        return

    while True:
        try:
            db_pool = await asyncpg.create_pool(
                user=DB_USER, password=DB_PASSWORD, database=DB_NAME, host=DB_HOST
            )
            async with db_pool.acquire() as conn:
                # Создаем таблицы (если их нет)
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS users (telegram_id BIGINT PRIMARY KEY, username TEXT, role TEXT DEFAULT 'worker', current_project_id INT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE IF NOT EXISTS projects (id SERIAL PRIMARY KEY, name TEXT NOT NULL, address TEXT, status TEXT DEFAULT 'active');
                    CREATE TABLE IF NOT EXISTS estimates (id SERIAL PRIMARY KEY, project_id INT REFERENCES projects(id) ON DELETE CASCADE, work_name TEXT NOT NULL, unit TEXT, price DECIMAL(10,2), total_qty DECIMAL(10,2));
                    CREATE TABLE IF NOT EXISTS progress (id SERIAL PRIMARY KEY, estimate_id INT REFERENCES estimates(id) ON DELETE CASCADE, user_id BIGINT REFERENCES users(telegram_id), qty_done DECIMAL(10,2), date TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE IF NOT EXISTS project_access (project_id INT REFERENCES projects(id) ON DELETE CASCADE, user_id BIGINT, PRIMARY KEY (project_id, user_id));
                """)
                # Создаем тестовый проект и админа
                await conn.execute("INSERT INTO projects (id, name, address) VALUES (1, 'ЖК Пилотный', 'ул. Тестовая 1') ON CONFLICT DO NOTHING;")
                await conn.execute("UPDATE users SET role = 'admin' WHERE telegram_id = $1", ADMIN_ID)
                
            logging.info("✅ PostgreSQL Connected Successfully!")
            return
        except Exception as e:
            logging.error(f"❌ Database Connection Error: {e}. Retrying in 5s...")
            await asyncio.sleep(5)

# Эту функцию мы вызываем во всех хендлерах
async def get_pool():
    global db_pool
    if db_pool is None or db_pool._closed:
        await init_db()
    return db_pool