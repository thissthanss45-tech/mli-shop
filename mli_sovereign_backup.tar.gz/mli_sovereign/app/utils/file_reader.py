import os
import PyPDF2
import docx
import openpyxl

def read_document_content(file_path: str) -> str:
    """
    Читает текст из файлов разных форматов:
    - .pdf (PyPDF2)
    - .docx (python-docx)
    - .xlsx (openpyxl) -> превращает в текстовый список строк
    """
    content = ""
    try:
        # 1. PDF
        if file_path.endswith(".pdf"):
            reader = PyPDF2.PdfReader(file_path)
            for page in reader.pages:
                text = page.extract_text()
                if text: content += text + "\n"
        
        # 2. Word (DOCX)
        elif file_path.endswith(".docx"):
            doc = docx.Document(file_path)
            content = "\n".join([p.text for p in doc.paragraphs])
            
        # 3. Excel (XLSX) - НОВОЕ
        elif file_path.endswith(".xlsx"):
            # data_only=True берет ЗНАЧЕНИЯ, а не формулы
            wb = openpyxl.load_workbook(file_path, data_only=True)
            
            for sheet in wb.worksheets:
                content += f"\n--- Лист: {sheet.title} ---\n"
                # Проходим по строкам
                for row in sheet.iter_rows(values_only=True):
                    # Собираем строку: "Бетон | м3 | 100"
                    # Фильтруем None (пустые ячейки)
                    cells = [str(cell) for cell in row if cell is not None]
                    if cells:
                        row_text = " | ".join(cells)
                        content += row_text + "\n"

        else:
            return "[Неизвестный формат. Пришлите PDF, DOCX или XLSX]"

    except Exception as e:
        return f"[Ошибка при чтении файла: {e}]"

    return content